#include <windows.h>

void *GetDialogArguments(HWND hDlg)
{
	return GetProp(hDlg,"InputArgument");
}

void ShowError(char *msg)
{
        HWND hWnd;
        hWnd = GetActiveWindow();
        if (IsIconic(hWnd)){
                ShowWindow(hWnd,SW_RESTORE);
        }
        MessageBox(hWnd, msg, "Error", 
		MB_OK | MB_ICONHAND|MB_TASKMODAL|MB_SETFOREGROUND);
}
