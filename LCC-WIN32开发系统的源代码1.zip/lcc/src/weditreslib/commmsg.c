/* Weditres support library. You should include this file in your projects
   built with weditres. It contains a small set of functions that will
   make the dynamic features of weditres work
*/
#define STRICT
#include <windows.h>
#include <commdlg.h>
#include <string.h>
#include <custcntl.h>
typedef int INT;
#define DARKGRAY                RGB(128, 128, 128)

typedef struct tagWeditDlgParams {
	int underscoreYOffset;
	DWORD TextColor;
	int Styles;
} WEDITDLGPARAMS;

typedef struct tagProgramParams {
	HPEN hGreyPen,hWhitePen,hThinWhitePen,hThinGreyPen;
	HFONT hHelv8Dlg;
	HFONT hHelv8;
	HBRUSH hBrushFond0;
	HBRUSH hBrushFond1;
	HBRUSH hBrushFond2;
	HBITMAP hBitMapCheckBox[2];
	HBITMAP hBitMapRadioButton[2];
	HCURSOR hcurWait;               /* User Wait cursor, Hourglass.         */
	HMENU ghMenuMain;               /* Main menu handle.                    */
	HPEN hpenDarkGray;       /* A dark gray pen.                     */
	COLORREF TextColor;
	COLORREF BackColor;
	COLORREF ColorLists;
	int FontSize;
	int underscoreYOffset;
	char FontName[LF_FACESIZE];
} PROGRAMPARAMS;

static PROGRAMPARAMS ProgramParams;

static FARPROC lpLBProc = NULL,tmpLBProc,
	lpCBProc,tmpCBProc;
static char *szButton = "Button";
static int gcyPixelsPerInch;
static HFONT CreateControlFontInternal(char *pszFontName,INT nPointSize,int weight);

#define SetStyleOn(hWnd,Style) SetWindowLong(hWnd,GWL_STYLE,Style|GetWindowLong(hWnd,GWL_STYLE))
#define SetStyleOff(hWnd,Style) SetWindowLong(hWnd,GWL_STYLE,(~Style)&GetWindowLong(hWnd,GWL_STYLE))




LRESULT FAR PASCAL SubClassListbox(HWND hwnd, UINT msg, WPARAM mp1, DWORD mp2)
{
	int i,count,width,lbwidth;
    HDC hDC;
	char lbtext[300];
	DWORD textExtent;
	HFONT hOldFont,hfont;
	SIZE pt;

	if (msg == WM_PAINT) {

		count = (int)SendMessage(hwnd,LB_GETCOUNT,0,0);
		width = 0;
		hfont = (HFONT)SendMessage(hwnd,WM_GETFONT,0,0);
		hDC = GetDC(hwnd);
		hOldFont = SelectObject(hDC,hfont);
		for (i=0; i<count;i++) {
			SendMessage(hwnd,LB_GETTEXT,i,(DWORD)lbtext);
			textExtent = GetTextExtentPoint(hDC,lbtext,strlen(lbtext),&pt);
	    if (pt.cx > width) width = pt.cx;
		}
		SelectObject(hDC,hOldFont);
		ReleaseDC(hwnd,hDC);
		lbwidth = SendMessage(hwnd,LB_GETHORIZONTALEXTENT,0,0);
		if (width > lbwidth) {
			PostMessage(hwnd,LB_SETHORIZONTALEXTENT,width,0);
			return(0);
	}
    }
	return(CallWindowProc((WNDPROC) lpLBProc, hwnd, msg, mp1, mp2));
}

LRESULT FAR PASCAL SubClassCombo(HWND hwnd, UINT msg, WPARAM mp1, DWORD mp2)
{
	return(CallWindowProc((WNDPROC) lpCBProc, hwnd, msg, mp1, mp2));
}


void SubClassList(HWND hwnd)
{
	if (lpLBProc == NULL) {
		lpLBProc = (FARPROC) GetWindowLong(hwnd, GWL_WNDPROC);
		tmpLBProc = MakeProcInstance((FARPROC) SubClassListbox, ghInst);
	}
	SetWindowLong(hwnd, GWL_WNDPROC, (DWORD) tmpLBProc);
}

static void SubClassComboBox(HWND hwnd)
{
	if (lpCBProc == NULL) {
		lpCBProc = (FARPROC) GetWindowLong(hwnd, GWL_WNDPROC);
		tmpCBProc = MakeProcInstance((FARPROC) SubClassCombo, ghInst);
	}
	SetWindowLong(hwnd, GWL_WNDPROC, (DWORD) tmpCBProc);
}
BOOL CALLBACK FontEnumProc(HWND hwnd, LPARAM lParam)
{
	SendMessage(hwnd,WM_SETFONT,(WPARAM)lParam,0L);
	return(1);
}
HFONT SetDialogFont(HWND hwnd,char *name,int size,int weight)
{
	HFONT result;

    result = CreateControlFontInternal(name,size,weight);
	EnumChildWindows(hwnd,FontEnumProc,(DWORD)result);
	return result;
}

BOOL CALLBACK ControlEnumProc(HWND hwnd, LPARAM lParam)
{
	long style;
	char classname[41];
    WEDITDLGPARAMS *wp;

	GetClassName(hwnd, classname, 40);
	SetProp(hwnd,"G",(HANDLE)LOWORD(lParam));
	wp = (WEDITDLGPARAMS *)GetWindowLong(GetParent(hwnd),DWL_USER);
	style = LOWORD(style);
	if (!strcmp(classname,"ComboBox")) {
		SubClassComboBox(hwnd);
	}
	else if (!strcmpi(classname,"ListBox")) {
		SubClassList(hwnd);
    }
	return 1;
}

static int SetFocusToFirstControl(HWND hDlg,int wParam)
{
	HWND hwndCtrl;
	char classname[41];
	long style;

	hwndCtrl = (HWND)wParam;
	GetClassName(hwndCtrl, classname, 40);
	if (!strcmp(classname, szButton)) {
		style = GetWindowLong(hwndCtrl, GWL_STYLE);
		if (LOWORD(style) == BS_GROUPBOX) return(FALSE);
	}
	return(FALSE);
}
BOOL CALLBACK RemovePropEnumProc(HWND hwnd, LPARAM lParam)
{
	RemoveProp(hwnd,"G");
	RemoveProp(hwnd,"C1");
	RemoveProp(hwnd,"C2");
    return(1);
}
int _stdcall HandleDefaultMessages(HWND hDlg, unsigned message, WPARAM wParam, LONG lParam)
{
	char classname[40];
	long ws;

	switch (message) {
	case WM_CLOSE:
		EndDialog(hDlg, 0);
		return (TRUE);
	case WM_INITDIALOG:
		GetClassName((HWND)wParam, classname, 40);
        if (!GetProp(hDlg,"BKC"))
			SetProp(hDlg,"BKC",ProgramParams.hBrushFond0);
		if (!strcmp(classname,szButton)) {
			ws = GetWindowLong((HWND)wParam, GWL_STYLE);
			if (LOWORD(ws) == BS_GROUPBOX) return(0);
		}
		return (SetFocusToFirstControl(hDlg,wParam));
	case WM_COMMAND:
		switch (wParam) {
		case IDOK:
			EndDialog(hDlg,1);
			return(TRUE);
		case IDCANCEL:
			EndDialog(hDlg, 0);
			return (TRUE);
		}
		break;
	case WM_LBUTTONUP:
		if (wParam == HTCLIENT) {
			SendMessage(hDlg, WM_NCLBUTTONUP, HTCAPTION, lParam);
			return (1);
		}
		else
			return (0);
	case WM_LBUTTONDBLCLK:
		if (wParam == HTCLIENT) {
			SendMessage(hDlg, WM_NCLBUTTONDBLCLK, HTCAPTION, lParam);
			return (1);
		}
		else
			return (0);
	case WM_LBUTTONDOWN:
		if (wParam == HTCLIENT) {
			SendMessage(hDlg, WM_NCLBUTTONDOWN, HTCAPTION, lParam);
			return (1);
		}
		else
			return (0);
	case WM_CTLCOLORBTN:
		ws = GetWindowLong((HWND) lParam, GWL_STYLE);
		if (ws & BS_PUSHBUTTON)
			return (0);
		SetBkMode((HDC) wParam, TRANSPARENT);
		SetTextColor((HDC) wParam, ProgramParams.TextColor);
		return ((int) ProgramParams.hBrushFond0);
	case WM_CTLCOLORDLG:
		return ((int) ProgramParams.hBrushFond0);
	case WM_CTLCOLORLISTBOX:
		SetBkMode((HDC) wParam, TRANSPARENT);
//		SetBkColor((HDC) wParam, hBrushFondList);
		SetTextColor((HDC) wParam, RGB(0, 0, 0));
		GetClassName((HWND) lParam, classname, 40);
		if (!strcmp(classname, "ComboBox"))
			return ((LRESULT) ProgramParams.hBrushFond0);
		else
			return ((int) ProgramParams.hBrushFond1);
	case WM_CTLCOLORSTATIC:
		SetBkMode((HDC) wParam, TRANSPARENT);
		SetTextColor((HDC) wParam, ProgramParams.TextColor);
		return ((int) ProgramParams.hBrushFond0);
	case WM_CTLCOLOREDIT:
	case WM_CTLCOLORMSGBOX:
		SetBkColor((HDC)wParam,ProgramParams.ColorLists);
		return ((int) ProgramParams.hBrushFond1);

	case WM_DESTROY:
		EnumChildWindows(hDlg,RemovePropEnumProc,0);
	return(0);
	default:
		return (FALSE);
	}
	return (FALSE);
}
static  VOID FitRectToScreen(PRECT prc)
{
	INT cxScreen;
	INT cyScreen;
	INT delta;
	cxScreen = GetSystemMetrics(SM_CXSCREEN);
	cyScreen = GetSystemMetrics(SM_CYSCREEN);
	if (prc->right > cxScreen) {
		delta = prc->right - prc->left;
		prc->right = cxScreen;
		prc->left = prc->right - delta;
	}
	if (prc->left < 0) {
		delta = prc->right - prc->left;
		prc->left = 0;
		prc->right = prc->left + delta;
	}
	if (prc->bottom > cyScreen) {
		delta = prc->bottom - prc->top;
		prc->bottom = cyScreen;
		prc->top = prc->bottom - delta;
	}
	if (prc->top < 0) {
		delta = prc->bottom - prc->top;
		prc->top = 0;
		prc->bottom = prc->top + delta;
	}
}

VOID CenterWindow(HWND hwnd,int wflag)
{
	RECT rc;
	RECT rcOwner;
	RECT rcCenter;
	HWND hwndOwner;
	GetWindowRect(hwnd, &rc);
   if (wflag) {
		if (!(hwndOwner = GetWindow(hwnd, GW_OWNER)))
			hwndOwner = GetDesktopWindow();
	}
	else {
		int xScreen,yScreen;
		POINT pt;

		GetWindowRect(hwnd,&rc);
		xScreen = GetSystemMetrics(SM_CXSCREEN);
		yScreen = GetSystemMetrics(SM_CYSCREEN);
		pt.x = xScreen/2 - (rc.right-rc.left)/2;
		pt.y = yScreen/2 - (rc.bottom-rc.top)/2;
		SetWindowPos(hwnd,HWND_TOP,pt.x,pt.y,0,0,SWP_NOSIZE|SWP_NOZORDER);
		return;
	}
	GetWindowRect(hwndOwner, &rcOwner);
	/* Calculate the starting x,y for the new window so that it would be
	centered. */
	rcCenter.left = rcOwner.left +
		(((rcOwner.right - rcOwner.left) -
		(rc.right - rc.left))
		/ 2);
	rcCenter.top = rcOwner.top +
		(((rcOwner.bottom - rcOwner.top) -
		(rc.bottom - rc.top))
		/ 2);
	rcCenter.right = rcCenter.left + (rc.right - rc.left);
	rcCenter.bottom = rcCenter.top + (rc.bottom - rc.top);
	FitRectToScreen(&rcCenter);
	SetWindowPos(hwnd, NULL, rcCenter.left, rcCenter.top, 0, 0,
				SWP_NOACTIVATE | SWP_NOSIZE | SWP_NOZORDER);
}



INT PointSizeToPixels(INT nPointSize)
{
	return MulDiv(nPointSize, gcyPixelsPerInch, 72);
}

static HFONT CreateControlFontInternal(char *pszFontName,INT nPointSize,int weight)
{
	HFONT hFont;
	LOGFONT lf;

	/*
	* Initialize the logical font structure.  Note that filling the
	* structure with zeros gives it all the default settings.
	*/
	memset(&lf, 0, sizeof(LOGFONT));
	lf.lfHeight = (short)-PointSizeToPixels(nPointSize);
	lf.lfWeight = weight;
	lstrcpy(lf.lfFaceName, pszFontName);

	if (!(hFont = CreateFontIndirect(&lf)))
		return NULL;

	/*
	* If we didn't get the face name that was requested, delete the
	* new font and return NULL.  This will effectively select the
	* system font for this dialog.
	*/
	return hFont;
}

#define MAXOBJECTS 60

typedef struct tagRessourcesList {
	struct tagRessourcesList *Next;
	HWND hwnd;
	HANDLE GdiObject[MAXOBJECTS];
	HANDLE mem;
    int NbOfObjects;
} RESOURCESLIST;

static RESOURCESLIST *GdiObjectsList = NULL;

void AddGdiObject(HWND hwnd,HANDLE hGdiObj)
{
	RESOURCESLIST *rvp;
	HANDLE mem;

	rvp = GdiObjectsList;

	while (rvp) {
		if (rvp->hwnd == hwnd) break;
	rvp = rvp->Next;
	}
	if (rvp == NULL) {
		mem = GlobalAlloc(GMEM_ZEROINIT|GPTR,(DWORD)sizeof(RESOURCESLIST));
		rvp = (RESOURCESLIST *)GlobalLock(mem);
		rvp->mem = mem;
		rvp->hwnd = hwnd;
		rvp->Next = GdiObjectsList;
		GdiObjectsList = rvp;
    }
	rvp->GdiObject[rvp->NbOfObjects++] = hGdiObj;
}

HFONT CreateControlFont(HWND hwnd,char *pszFontName,INT nPointSize,int weight)
{
	HFONT hFont;

	hFont = CreateControlFontInternal(pszFontName,nPointSize,weight);
    AddGdiObject(hwnd,hFont);
	return(hFont);
}
int IsHwndInList(HWND hwnd)
{
	RESOURCESLIST *rvp;

	rvp = GdiObjectsList;
	while (rvp) {
		if (rvp->hwnd == hwnd) return(1);
		rvp = rvp->Next;
	}
	return(0);
}

BOOL CALLBACK  DestroyProc(HWND hwnd, LPARAM lParam)
{
	DestroyWindow(hwnd);
	return(1);
}

void DestroyChildWindows(HWND hwnd)
{
	EnumChildWindows(hwnd,DestroyProc,0L);
}

void FreeGdiObjects(HWND hwnd)
{
	RESOURCESLIST *rvp,*last;
    int i;

	rvp = GdiObjectsList;
    last = NULL;
	while (rvp) {
		if (rvp->hwnd == hwnd) {
			if (last == NULL) {
		GdiObjectsList = GdiObjectsList->Next;
			}
			else {
		last->Next = rvp->Next;
			}
			for (i=0; i<rvp->NbOfObjects;i++) {
		DeleteObject(rvp->GdiObject[i]);
	    }
			GlobalFree(rvp->mem);
			return;
		}
	last = rvp;
	rvp = rvp->Next;
	}
}

static int TestIntegerInternal(HWND hwnd,char *extra)
{
	char tbuf[70];
	int cb,i,c;
    char *p;

	cb = GetWindowText(hwnd,tbuf,68);
	tbuf[cb] = 0;
	i = 0;
    while (tbuf[i] == ' ') i++;
	for (; i<cb;i++) {
		c = tbuf[i];
		if (!(c >= '0' && c <='9')) {
			p = extra;
			while (*p && *p != c) p++;
			if (!*p) {
				tbuf[i] = 0;
				MessageBeep(0xFFFFFFFF);
				SetWindowText(hwnd,tbuf);
				SendMessage(hwnd,EM_SETSEL,0,MAKELPARAM(i,10000));
		return(0);
	    }
	}
	}
	return(1);
}

int TestAlpha(HWND hwnd,int extra)
{
	char tbuf[70];
	int cb,i,c;

	cb = GetWindowText(hwnd,tbuf,68);
	tbuf[cb] = 0;
	i = 0;
    while (tbuf[i] == ' ') i++;
	for (; i<cb;i++) {
		c = tbuf[i];
	if (c >= 'a' && c <= 'z') c -= ' ';
		if (!(c >= 'A' && c <='Z')) {
			tbuf[i] = 0;
			MessageBeep(0xFFFFFFFF);
			SetWindowText(hwnd,tbuf);
			SendMessage(hwnd,EM_SETSEL,0,MAKELPARAM(i,10000));
	    return(0);
	}
	}
	return(1);
}

int TestInteger(HWND hwnd)
{
	return(TestIntegerInternal(hwnd,"+-"));
}
int TestPositiveInteger(HWND hwnd)
{
	return(TestIntegerInternal(hwnd,"+"));
}
int TestNumber(HWND hwnd)
{
	return(TestIntegerInternal(hwnd,"+-."));
}
void SetDefaultStyle(HANDLE ghInst)
{
	HDC hDC;

    hDC = GetDC(NULL);
	gcyPixelsPerInch = GetDeviceCaps(hDC,LOGPIXELSY);
	ReleaseDC(NULL,hDC);
	strcpy(ProgramParams.FontName,"Helv");
	ProgramParams.FontSize = 8;
	ProgramParams.TextColor = RGB(0,0,0);
	ProgramParams.BackColor = RGB(128,128,128);
	ProgramParams.ColorLists = RGB(255,255,255);
	/* Create a dark gray pen for use in borders later. */
	ProgramParams.hpenDarkGray = CreatePen(PS_SOLID, 1, DARKGRAY);
	/* Create the thin font for the floating toolbox */
	ProgramParams.hWhitePen = CreatePen(PS_SOLID,2,RGB(255,255,255));
	ProgramParams.hGreyPen = CreatePen(PS_SOLID,2,RGB(128,128,128));
	ProgramParams.hThinGreyPen = CreatePen(PS_SOLID,1,RGB(128,128,128));
	ProgramParams.hThinWhitePen = GetStockObject(WHITE_PEN);
}
