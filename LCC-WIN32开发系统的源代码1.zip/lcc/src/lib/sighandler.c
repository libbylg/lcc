#include <windows.h>
extern EXCEPTION_RECORD *_CurrentException;
extern int _currentline;
extern char *_currentfunction;
extern char *_currentfile;
extern CONTEXT *_CurrentContext;
typedef struct __ShadowStackStruct {
	unsigned char *currentfunction;
	unsigned int CurrentLine;
	unsigned char *Module;
} StackStruct;
extern StackStruct *_ShadowStack;
extern int _debuglevel;
void _lccStackTrace(int sig)
{
	char msg[1024];
	int i,l,offset;
	StackStruct *pStack;
	char *ptr,fl[20],*after;

	msg[0] = 0;
	pStack = _ShadowStack;
	pStack--;
	for (i=0; i<10 && !IsBadReadPtr(pStack,sizeof(StackStruct));i++) {
		l = pStack->CurrentLine & 0xFFFF;
		offset = pStack->CurrentLine >> 16;
		if (!IsBadReadPtr(pStack->currentfunction,4) && 
			l < 65535 && offset < 65535 &&
			!IsBadReadPtr(pStack->Module,4)) {
			if (_debuglevel == 3 && i == 0) {
				l = 0;
				strcpy(fl,"unknown line");
				after = "after";
			}
			else {
				sprintf(fl,"%d",l);
				after = "";
			}
			if (pStack->currentfunction[0] > 32 && pStack->currentfunction[0] < 128 &&
				pStack->Module[0] > 32 && pStack->Module[0] < 128)
				sprintf(msg+strlen(msg),"%3d %s [%s] %s %s %d\n",i,pStack->currentfunction,fl,
					pStack->Module,after,offset+l);
			else
				sprintf(msg+strlen(msg),"unknown\n");
		}
		else break;
		if (strlen(msg) > 900)
			break;
		ptr = (char *)pStack;
		ptr += sizeof(StackStruct);
		pStack = *((StackStruct **)ptr);
		if (pStack)
			pStack--;
		else break;
	}
	if (msg[0] == 0 && _ShadowStack)
		sprintf(msg,"Corrupted stack. Impossible to show trace\n");
	else if (i == 10) sprintf(msg+strlen(msg),"    ...\n");
	strcat(msg,"\n");
	if (sig && !IsBadReadPtr(_CurrentContext,sizeof(CONTEXT))) {
		if (_CurrentContext->Ebp != (unsigned long)_ShadowStack ||
			_CurrentContext->Ebp < _CurrentContext->Esp) {
			sprintf(msg+strlen(msg),"Fault occurred outside a function scope\n");
		}
		sprintf(msg+strlen(msg),"    Current instruction: 0x%x\n",_CurrentContext->Eip);
	}
	i = MessageBox(0,msg,"lcc runtime: GP fault.       Stack trace",MB_OKCANCEL|MB_ICONSTOP|MB_SETFOREGROUND);
	if (i == 2) {
		sprintf(msg,"wedit.exe -p %d ",GetCurrentProcessId());
		WinExec(msg,SW_SHOW);
		for (; ;)
			Sleep(10);
		return;
	}
	if (sig)
		_exit(-1);
}
