#include "c.h"
extern Interface x86IR;
Binding bindings[] = {
	"x86-dos",       &x86IR,
	NULL,            NULL
};
