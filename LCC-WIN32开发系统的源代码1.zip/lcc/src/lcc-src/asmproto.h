/* Prototypes for D:\NGAS1\ASM.C. Generated  1995.11.4.13.25.47 */

#ifndef T_ASMPROTO_H_ID
#define T_ASMPROTO_H_ID
static char * xmalloc (long n );
static void error (char * s );
static void append (char * * charPP ,char * fromP ,unsigned long length );
static void subsegs_begin (void);
static void subseg_change (register segT seg ,register int subseg );
static void subseg_new (register segT seg ,register subsegT subseg );
static void symbol_begin (void);
static symbolS * symbol_new (char * name ,unsigned char type ,valueT value ,struct frag * frag );
static void colon (register char * sym_name );
static void symbol_table_insert (struct symbol * symbolP );
static void SetFlags(symbolS *coffS);
static symbolS * symbol_find_or_make (char * name );
static void frag_grow (unsigned int nchars );
static void frag_new (int old_frags_var_max_size );
static char * frag_more (int nchars );
static char * frag_var (relax_stateT type ,int max_chars ,int var ,relax_substateT subtype ,symbolS * symbol ,long int offset ,char * opcode );
static void frag_wane (fragS * fragP );
static void frag_align (int alignment ,int fill_character );
static segT operand (register expressionS * expressionP );
static void clean_up_expression (register expressionS * expressionP );
static segT expr_part (struct symbol * * symbol_1_PP ,struct symbol * symbol_2_P );
static segT expr (register operator_rankT rank ,register expressionS * resultP );
static char get_symbol_end (void);
static char * input_file_give_next_buffer (char * where );
static void InitAsmInput (void);
static char * input_scrub_new_file (char * filename );
static char * input_scrub_next_buffer (char * * bufp );
static void bump_line_counters (void);
static void as_where (void);
static void as_perror (char * gripe ,char * filename );
static void _obstack_begin (struct obstack * h ,int size ,int alignment ,void *(*chunkfun )(),void (* freefun )());
static void _obstack_newchunk (struct obstack * h ,int length );
static void read_begin (void);
static char * hash_insert (struct HASH_LIST * where ,char * name ,char * data );
static char * hash_find (struct HASH_LIST * w ,char * n );
static struct HASH_LIST * hash_new (void);
static char * hash_jam (struct HASH_LIST * where ,char * n ,char * data );
static void pobegin (void);
static void read_a_source_file (char * buffer );
static void s_align (void);
static void s_comm (void);
static void s_data (void);
static void s_file (void);
static void s_globl (void);
static void s_lcomm (void);
static void s_line (void);
static void s_long (void);
static void s_int (void);
static void s_lsym (void);
static void s_space (void);
static void s_text (void);
static void s_type (void);
static void s_size (void);
static void demand_empty_rest_of_line (void);
static void ignore_rest_of_line (void);
static void stab (int what );
static void pseudo_set (symbolS * symbolP );
static void cons (int nbytes );
static void stringer (int append_zero );
static int next_char_of_string (void);
static segT get_segmented_expression (register expressionS * expP );
static segT get_known_segmented_expression (expressionS * expP );
static long int get_absolute_expression (void);
static char get_absolute_expression_and_terminator (long int * val_pointer );
static char * demand_copy_C_string (int * len_pointer );
static char * demand_copy_string (int * lenP );
static int is_it_end_of_statement (void);
static void equals (char * sym_name );
static void InitializeAsmTables (void);
static void AsmI386Instruction (char * line );
static int i386_operand (char * operand_string );
static int md_estimate_size_before_relax (register fragS * fragP ,register int segment_type );
static void md_convert_frag (register fragS * fragP );
static void md_number_to_chars (char con [ ] ,long int value ,int nbytes );
static char * output_invalid (char c );
static reg_entry * parse_register (char * reg_string );
static void WriteCoffHeader (int ns );
static long WriteTextSection (long siz ,long nfixups );
static long WriteDataSection (long siz ,long nfixups ,int addr );
static long WriteBssSection (long siz );
static int ArrangeDataSection (int ordinal );
static int ArrangeOrdinalNumbers (char * name );
static int SortFun (const void * f1 ,const void * f2 );
static int WriteRelocations (int which);
static STRING * NewString (char * s ,int len );
static int AddStringToStringTable (char * str );
static long WriteStringTable (void);
static int SortSymbols (const void * f1 ,const void * f2 );
static int WriteLineNumbers (int PosCodeSection );
static int WriteOneSymbol (char * p );
static int WriteFunctionRecords (symbolS * coffS );
static int SymbolToChars (symbolS * coffS );
static int WriteDataSymbols (int count );
static int WriteSpecialSymbols (int result );
static int WriteAllCoffSymbols (int startCount );
static int WriteFileName (char * name );
static COFF_RELOC * AddCoffRelocation (symbolS * coffS ,int where ,int pcrel );
static void fix_new (fragS * frag ,int where ,short int size ,symbolS * add_symbol ,symbolS * sub_symbol ,long int offset ,int pcrel );
static void relax_segment (struct frag * segment_frag_root ,segT segment_type );
static relax_addressT relax_align (register relax_addressT address ,register long int alignment );
static long int fixup_segment (fixS * fixP ,int this_segment_type );
static int emit_relocations (register fixS * fixP);
static int is_dnrange (struct frag * f1 ,struct frag * f2 );
int main (int argc ,char * * argv );
void WriteError(void);
void InternalError(int err);
static void MakeBssSymbol(symbolS *symbolP,int siz,int localflag);
#endif
