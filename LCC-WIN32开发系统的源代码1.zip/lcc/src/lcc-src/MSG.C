/* Wedit String Table */
char *StrTab[]={
/* strings from D:\LCC\SRC44\MAIN.C */
	"Impossible to open %s\n",	/* 0 */
	"lcc: break. Erasing %s\n",	/* 1 */
	"Trap signal received. Compilation aborts\n",	/* 2 */
	"no input files\n",	/* 3 */
	"%s: can't write `%s'\n",	/* 4 */
	"Cpp time: %g sec.\n",	/* 5 */
	"%s: can't write `%s: error %d'\n",	/* 6 */
	"Spills:%d Chars read: %d,Memory used:%d,Time = %g sec.\n",	/* 7 */
	"%d errors, %d warnings\n",	/* 8 */
	"Clobbering input file %s with xref file %s?\n",	/* 9 */
	"Option error: /Fo needs an argument\n" 	/* 10 */
	,
/* strings from D:\LCC\SRC44\W32INCL.C */
	"Unknown operation in boolean assignment\n" 	/* 11 */
	,
/* strings from D:\LCC\SRC44\TYPES.C */
	"type error: %s\n",	/* 12 */
	"pointer expected",	/* 13 */
	"illegal type `array of %t'\n",	/* 14 */
	"missing array size\n",	/* 15 */
	"illegal type `array of %t'\n",	/* 16 */
	"declaring type array of %t' is undefined\n",	/* 17 */
	"size of `array of %t' exceeds %d bytes\n",	/* 18 */
	"type error: %s\n",	/* 19 */
	"array expected",	/* 20 */
	"Pascal keyword not implemented",	/* 21 */
	"qualified function type ignored\n",	/* 22 */
	"illegal type `%k %t'\n",	/* 23 */
	"illegal return type `%t'\n",	/* 24 */
	"type error: %s\n",	/* 25 */
	"function expected",	/* 26 */
	"redefinition of `%s' previously defined at %w\n",	/* 27 */
	"duplicate field name `%s' in `%t'\n",	/* 28 */
	"ambiguous field `%s' of `%t' from `%t'\n",	/* 29 */
	"incomplete ",	/* 30 */
	"%k defined at %w",	/* 31 */
	" defined at %w",	/* 32 */
	"pointer to %t",	/* 33 */
	"%t function",	/* 34 */
	"incomplete array",	/* 35 */
	" of %t",	/* 36 */
	"%t _stdcall ",	/* 37 */
	"long long ",	/* 38 */
	"%s;\n",	/* 39 */
	"%k %s;\n",	/* 40 */
	"%k %s size=%d {\n",	/* 41 */
	"field %s: offset=%d",	/* 42 */
	" bits=%d..%d",	/* 43 */
	" type=%t",	/* 44 */
	"}\n",	/* 45 */
	"enum %s {",	/* 46 */
	",",	/* 47 */
	"%s=%d",	/* 48 */
	"}\n",	/* 49 */
	"%t\n",	/* 50 */
	"unnamed %k in prototype\n" 	/* 51 */
	,
/* strings from D:\LCC\SRC44\TREE.C */
	"reference to `%t' elided\n",	/* 52 */
	"reference to `volatile %t' elided\n" 	/* 53 */
	,
/* strings from D:\LCC\SRC44\TRACE.C */
	") called\n" 	/* 54 */
	,
/* strings from D:\LCC\SRC44\SYM.C */
	"Extending %s to %d\n",	/* 55 */
	"more than 127 identifiers declared in a block\n" 	/* 56 */
	,
/* strings from D:\LCC\SRC44\STMT.C */
	"unreachable code\n",	/* 57 */
	"more than 15 levels of nested statements\n",	/* 58 */
	"illegal break statement\n",	/* 59 */
	"illegal continue statement\n",	/* 60 */
	"illegal case label\n",	/* 61 */
	"case label must be a constant integer expression\n",	/* 62 */
	"illegal default label\n",	/* 63 */
	"extra default label\n",	/* 64 */
	"extraneous return value\n",	/* 65 */
	"missing return value\n",	/* 66 */
	"missing label in goto\n",	/* 67 */
	"unrecognized statement\n",	/* 68 */
	"illegal statement termination\n",	/* 69 */
	"%s used in a conditional expression\n",	/* 70 */
	"redefinition of label `%s' previously defined at %w\n",	/* 71 */
	"illegal type `%t' in switch expression\n",	/* 72 */
	"switch statement with no cases\n",	/* 73 */
	"duplicate case label `%d'\n",	/* 74 */
	"more than 257 cases in a switch\n",	/* 75 */
	"switch generates a huge table\n",	/* 76 */
	"illegal return type; found `%t' expected `%t'\n",	/* 77 */
	"pointer to a %s is an illegal return value\n",	/* 78 */
	"parameter",	/* 79 */
	"local",	/* 80 */
	"pointer to %s `%s' is an illegal return value\n",	/* 81 */
	"parameter",	/* 82 */
	"local",	/* 83 */
	"source code specifies an infinite loop" 	/* 84 */
	,
/* strings from D:\LCC\SRC44\SIMP.C */
	"integer expression must be constant\n",	/* 85 */
	"Overflow in constant expression\n",	/* 86 */
	"Overflow in constat expression\n",	/* 87 */
	"overflow in constant expression\n",	/* 88 */
	"shift by %d is undefined\n",	/* 89 */
	"shift by %d is undefined\n",	/* 90 */
	"shift by %d is undefined\n",	/* 91 */
	"overflow in constant expression\n",	/* 92 */
	"shift by %d is undefined\n",	/* 93 */
	"shift by %d is undefined\n",	/* 94 */
	"overflow in constant expression\n",	/* 95 */
	"overflow in constant expression\n",	/* 96 */
	"overflow in constant expression\n" 	/* 97 */
	,
/* strings from D:\LCC\SRC44\SEH.C */
	"Incorrect __except syntax\n",	/* 98 */
	"Incorrect __except expression!",	/* 99 */
	"missing ')' in __except expression" 	/* 100 */
	,
/* strings from D:\LCC\SRC44\NCPP.C */
	"Unterminated conditional in #include",	/* 101 */
	"Unterminated #if/#ifdef/#ifndef",	/* 102 */
	"Unidentifiable control line",	/* 103 */
	"Unknown preprocessor control %t",	/* 104 */
	"#if too deeply nested",	/* 105 */
	"Syntax error in #undef",	/* 106 */
	"#if too deeply nested",	/* 107 */
	"#elif with no #if",	/* 108 */
	"#elif after #else",	/* 109 */
	"#else with no #if",	/* 110 */
	"#else after #else",	/* 111 */
	"Syntax error in #else",	/* 112 */
	"#endif with no #if",	/* 113 */
	"Syntax error in #endif",	/* 114 */
	"#error directive: %r",	/* 115 */
	"Syntax error in #line",	/* 116 */
	"#line specifies number out of range",	/* 117 */
	"Bad syntax for control line",	/* 118 */
	"Preprocessor control `%t' not yet implemented",	/* 119 */
	"Out of memory from malloc",	/* 120 */
	"Syntax error in #ifdef/#ifndef",	/* 121 */
	"Illegal operator * or & in #if/#elsif",	/* 122 */
	"Bad operator (%t) in #if/#elsif",	/* 123 */
	"Botch in #if/#elsif",	/* 124 */
	"Undefined expression value",	/* 125 */
	"Syntax error in #if/#elsif",	/* 126 */
	"Syntax error in #if/#endif",	/* 127 */
	"Bad ?: in #if/endif",	/* 128 */
	"Eval botch (unknown operator)",	/* 129 */
	"Bad digit in number %t",	/* 130 */
	"Bad number %t in #if/#elsif",	/* 131 */
	"Wide char constant value undefined",	/* 132 */
	"Undefined escape in character constant",	/* 133 */
	"Empty character constant",	/* 134 */
	"Multibyte character constant undefined",	/* 135 */
	"Character constant taken as not signed",	/* 136 */
	"String in #if/#elsif",	/* 137 */
	"#include too deeply nested",	/* 138 */
	"Could not find include file %r",	/* 139 */
	"Syntax error in #include",	/* 140 */
	"Lexical botch in cpp",	/* 141 */
	"No newline at end of file",	/* 142 */
	"Unterminated string or char const",	/* 143 */
	"EOF in string or char constant",	/* 144 */
	"EOF inside comment",	/* 145 */
	"#defined token is not a name",	/* 146 */
	"#defined token %t can't be redefined",	/* 147 */
	"Duplicate macro argument",	/* 148 */
	"Syntax error in macro parameters",	/* 149 */
	"Macro redefinition of %t",	/* 150 */
	"Illegal -D or -U argument %r",	/* 151 */
	"Incorrect syntax for 'defined'",	/* 152 */
	"Disagreement in number of macro arguments",	/* 153 */
	"EOF in macro arglist",	/* 154 */
	"Sorry, too many macro arguments",	/* 155 */
	"# not followed by macro parameter",	/* 156 */
	"## occurs at border of replacement",	/* 157 */
	"Bad token %r produced by ##",	/* 158 */
	"Stringified macro arg is too long",	/* 159 */
	"bad __declspec syntax!",	/* 160 */
	"cpp botch: unknown internal macro",	/* 161 */
	"Token of length 0?\n",	/* 162 */
	"(tp offset %d) ",	/* 163 */
	"Cpp: Input buffer overflow!!!\n",	/* 164 */
	"Installation problem\n",	/* 165 */
	"Please enter the path for the <include> header files (for example c:\\lcc\\include)\n",	/* 166 */
	"%s is not a directory. Exiting\n",	/* 167 */
	"Too many -I directives",	/* 168 */
	"Can't open input file %s",	/* 169 */
	"Clobbering input file? %s\n" 	/* 170 */
	,
/* strings from D:\LCC\SRC44\LEX.C */
	"asm string too long\n",	/* 171 */
	"too many variable references in asm string\n",	/* 172 */
	"non-ANSI asm\n",	/* 173 */
	"missing string constant in asm\n",	/* 174 */
	"unclosed comment\n",	/* 175 */
	"invalid hexadecimal constant `%S'\n",	/* 176 */
	"invalid octal constant `%S'\n",	/* 177 */
	"missing %c\n",	/* 178 */
	"%s literal too long\n",	/* 179 */
	"string",	/* 180 */
	"character",	/* 181 */
	"more than 509 characters in a string literal\n",	/* 182 */
	"%s literal contains non-portable characters\n",	/* 183 */
	"string",	/* 184 */
	"character",	/* 185 */
	"excess characters in multibyte character literal `%S' ignored\n",	/* 186 */
	"missing '\n",	/* 187 */
	"illegal character `\\0%o'\n",	/* 188 */
	"illegal character `%c'\n",	/* 189 */
	"overflow in constant `%S'\n",	/* 190 */
	"integer",	/* 191 */
	"`%S' is a preprocessing number but an invalid %s constant\n",	/* 192 */
	"invalid floating constant `%S'\n",	/* 193 */
	"overflow in double constant `%S'\n",	/* 194 */
	"overflow in floating constant `%S'\n",	/* 195 */
	"floating",	/* 196 */
	"ill-formed hexadecimal escape sequence\n",	/* 197 */
	"ill-formed hexadecimal escape sequence `\\x%c'\n",	/* 198 */
	"overflow in hexadecimal escape sequence\n",	/* 199 */
	"overflow in octal escape sequence\n",	/* 200 */
	"unrecognized character escape sequence\n",	/* 201 */
	"unrecognized character escape sequence `\\%c'\n",	/* 202 */
	"Overflow in #pragma(push)\n",	/* 203 */
	"Syntax error in pragma <pack>\n",	/* 204 */
	"pragma pack(pop) stack underflow\n",	/* 205 */
	"pragma pack(pop) syntax error\n",	/* 206 */
	"Integer constant expected in 'pack' pragma. Ignored.",	/* 207 */
	"Incorrect 'pragma pack' syntax",	/* 208 */
	"Illegal pragma pack(%d) ignored",	/* 209 */
	"Incorrect syntax in pragma statement",	/* 210 */
	"Integer constant expected in 'optimize' pragma. Ignored.",	/* 211 */
	"Incorrect 'optimize' syntax",	/* 212 */
	"Incorrect syntax in pragma statement",	/* 213 */
	"String constant expected in 'pack' pragma. Ignored.",	/* 214 */
	"\tsection .text\n",	/* 215 */
	"Section name too long. Max. 8 chars. Ignored.",	/* 216 */
	"Incorrect 'pragma section' syntax",	/* 217 */
	"Incorrect syntax in pragma statement" 	/* 218 */
	,
/* strings from D:\LCC\SRC44\INPUT.C */
	"read error\n",	/* 219 */
	"ref",	/* 220 */
	"pack",	/* 221 */
	"section",	/* 222 */
	"optimize",	/* 223 */
	"pragma",	/* 224 */
	"missing \" in preprocessor line\n",	/* 225 */
	"line",	/* 226 */
	"unrecognized control line\n",	/* 227 */
	"unrecognized control line\n" 	/* 228 */
	,
/* strings from D:\LCC\SRC44\INIT.C */
	"initializer must be constant\n",	/* 229 */
	"cast from `%t' to `%t' is illegal in constant expressions\n",	/* 230 */
	"initializer must be constant\n",	/* 231 */
	"invalid initialization type; found `%t' expected `%s'\n",	/* 232 */
	"initializer exceeds bit-field width\n",	/* 233 */
	"invalid initialization type; found `%t' expected `%t'\n",	/* 234 */
	"cannot initialize undefined `%t'\n",	/* 235 */
	"missing { in initialization of `%t'\n",	/* 236 */
	"invalid initialization type; found `%t' expected `%t'\n",	/* 237 */
	"missing { in initialization of `%t'\n",	/* 238 */
	"missing { in initialization of `%t'\n",	/* 239 */
	"missing { in initialization of `%t'\n",	/* 240 */
	"too many initializers\n",	/* 241 */
	"invalid initialization type; found `%t' expected `%s'\n",	/* 242 */
	"initializer must be constant\n" 	/* 243 */
	,
/* strings from D:\LCC\SRC44\GEN.C */
	"Fatal error:\n",	/* 244 */
	"Expression too complicated\nEnclose this function within #pragma optimize(0)/(1)\n",	/* 245 */
	"No more registers available" 	/* 246 */
	,
/* strings from D:\LCC\SRC44\EXPR.C */
	"%s used in a conditional expression\n",	/* 247 */
	"invalid operand of unary &; `%s' is declared register\n",	/* 248 */
	"unsigned operand of unary -\n",	/* 249 */
	"invalid type argument `%t' to `sizeof'\n",	/* 250 */
	"`sizeof' applied to a bit field\n",	/* 251 */
	"non-ANSI constructor for `%t'\n",	/* 252 */
	"conversion from `%t' to `%t' is compiler dependent\n",	/* 253 */
	"cast from `%t' to `%t' is illegal\n",	/* 254 */
	"indexing array %s[%d] out of bounds (%d)\n",	/* 255 */
	"found `%t' expected a function\n",	/* 256 */
	"left operand of . has incompatible type `%t'\n",	/* 257 */
	"field name expected\n",	/* 258 */
	"left operand of -> has incompatible type `%t'\n",	/* 259 */
	"field name expected\n",	/* 260 */
	"missing prototype\n",	/* 261 */
	"undeclared identifier `%s'\n",	/* 262 */
	"illegal use of type name `%s'\n",	/* 263 */
	"illegal expression\n",	/* 264 */
	"lvalue required\n",	/* 265 */
	"`%t' used as an lvalue\n",	/* 266 */
	"conversion from `%t' to `%t' is compiler dependent\n",	/* 267 */
	"unknown field `%s' of `%t'\n",	/* 268 */
	"a function" 	/* 269 */
	,
/* strings from D:\LCC\SRC44\ERROR.C */
	"syntax error; found",	/* 270 */
	" expecting `%k'\n",	/* 271 */
	"too many errors\n",	/* 272 */
	"Error ",	/* 273 */
	"skipping",	/* 274 */
	" up to",	/* 275 */
	"compiler error in %s--",	/* 276 */
	" ...",	/* 277 */
	"Warning " 	/* 278 */
	,
/* strings from D:\LCC\SRC44\ENODE.C */
	"illegal use of incomplete type `%t'\n",	/* 279 */
	"type error in argument %d to %s; found `%t' expected `%t'\n",	/* 280 */
	"too many arguments to %s\n",	/* 281 */
	"type error in argument %d to %s; `%t' is illegal\n",	/* 282 */
	"more than 31 arguments in a call to %s\n",	/* 283 */
	"insufficient number of arguments to %s\n",	/* 284 */
	"unknown size for type `%t'\n",	/* 285 */
	"overflow in char comparison with constant %d\n",	/* 286 */
	"overflow in short comparison with constant %d\n",	/* 287 */
	"assignment between `%t' and `%t' is compiler-dependent\n",	/* 288 */
	"assignment of %t to %t\n",	/* 289 */
	"assignment to const identifier `%s'\n",	/* 290 */
	"assignment to const location\n",	/* 291 */
	"addressable object required\n",	/* 292 */
	"unknown size for type `%t'\n",	/* 293 */
	"unknown size for type `%t'\n",	/* 294 */
	"operands of %s have illegal types `%t' and `%t'\n",	/* 295 */
	"operand of unary %s has illegal type `%t'\n",	/* 296 */
	"operands of %s have different types `%t' and `%t'\n" 	/* 297 */
	,
/* strings from D:\LCC\SRC44\DECL.C */
	"empty declaration\n",	/* 298 */
	"unrecognized declaration\n",	/* 299 */
	"empty input file\n",	/* 300 */
	"invalid use of `%k'\n",	/* 301 */
	"invalid use of `%k'\n",	/* 302 */
	"no type specified. Defaulting to int\n",	/* 303 */
	"redefinition of %s\n",	/* 304 */
	"invalid type specification\n",	/* 305 */
	"invalid use of `typedef'\n",	/* 306 */
	"Incorrect usage of _stdcall",	/* 307 */
	"missing prototype\n",	/* 308 */
	"missing identifier\n",	/* 309 */
	"redeclaration of '%s'\n",	/* 310 */
	"redeclaration of `%s'\n",	/* 311 */
	"empty declaration\n",	/* 312 */
	"invalid storage class `%k' for `%t %s'\n",	/* 313 */
	"redeclaration of `%s' previously declared at %w\n",	/* 314 */
	"redefinition of `%s' previously defined at %w\n",	/* 315 */
	"inconsistent linkage for `%s' previously declared at %w\n",	/* 316 */
	"more than 511 external identifiers\n",	/* 317 */
	"declaration of `%s' does not match previous declaration at %w\n",	/* 318 */
	"illegal initialization for `%s'\n",	/* 319 */
	"undefined size for `%t %s'\n",	/* 320 */
	"more than 32767 bytes in `%t'\n",	/* 321 */
	"extraneous identifier `%s'\n",	/* 322 */
	"`%d' is an illegal array size\n",	/* 323 */
	"illegal formal parameter types\n",	/* 324 */
	"missing parameter type\n",	/* 325 */
	"illegal formal parameter types\n",	/* 326 */
	"missing prototype\n",	/* 327 */
	"expecting an identifier\n",	/* 328 */
	"extraneous old-style parameter list\n",	/* 329 */
	"invalid storage class `%k' for `%t%s\n",	/* 330 */
	"' parameter",	/* 331 */
	"register declaration ignored for `%t%s\n",	/* 332 */
	"' parameter",	/* 333 */
	"duplicate declaration for `%s' previously declared at %w\n",	/* 334 */
	"illegal initialization for parameter `%s'\n",	/* 335 */
	"invalid %k field declarations\n",	/* 336 */
	"missing %k tag\n",	/* 337 */
	"missing prototype for %s\n",	/* 338 */
	"missing prototype\n",	/* 339 */
	"`%t' is an illegal bit-field type\n",	/* 340 */
	"promoting %t to int\n",	/* 341 */
	"`%d' is an illegal bit-field size\n",	/* 342 */
	"extraneous 0-width bit field `%t %s' ignored\n",	/* 343 */
	"non-ANSI unnamed substructure in `%t'\n",	/* 344 */
	"undefined size for field `%t'\n",	/* 345 */
	"non-ANSI unnamed substructure\n",	/* 346 */
	"undefined size for field '%t'\n",	/* 347 */
	"`%t' is an illegal field type\n",	/* 348 */
	"undefined size for field `%t %s'\n",	/* 349 */
	"incorrect _stdcall usage",	/* 350 */
	"more than 127 fields in `%t'\n",	/* 351 */
	"size of `%t' exceeds %d bytes\n",	/* 352 */
	"illegal use of incomplete type `%t'\n",	/* 353 */
	"more than 31 parameters in function `%s'\n",	/* 354 */
	"conflicting argument declarations for function `%s'\n",	/* 355 */
	"missing prototype for `%s'\n",	/* 356 */
	"missing name for parameter %d to function `%s'\n",	/* 357 */
	"undefined size for parameter `%t %s'\n",	/* 358 */
	"redefinition of `%s' previously defined at %w\n",	/* 359 */
	"missing return value\n",	/* 360 */
	"Function %s nodes %d statements %d\n",	/* 361 */
	"declared parameter `%s' is missing\n",	/* 362 */
	"static `%t %s' is not referenced\n",	/* 363 */
	"parameter `%t %s' is not referenced\n",	/* 364 */
	"local `%t %s' is not referenced\n",	/* 365 */
	" %s is assigned a value that is never used\n",	/* 366 */
	" possible usage of %s before definition\n",	/* 367 */
	"undefined static `%t %s'\n",	/* 368 */
	"invalid storage class `%k' for `%t %s'\n",	/* 369 */
	"register declaration ignored for `%t %s'\n",	/* 370 */
	"redeclaration of `%s' previously declared at %w\n",	/* 371 */
	"declaration of `%s' does not match previous declaration at %w\n",	/* 372 */
	"undefined size for `%t %s'\n",	/* 373 */
	"illegal initialization of `extern %s'\n",	/* 374 */
	"undefined size for `%t %s'\n",	/* 375 */
	"undefined size for `%t %s'\n",	/* 376 */
	"undefined label `%s'\n",	/* 377 */
	"expecting an enumerator identifier\n",	/* 378 */
	"redeclaration of `%s' previously declared at %w\n",	/* 379 */
	"overflow in value for enumeration constant `%s'\n",	/* 380 */
	"more than 127 enumeration constants in `%t'\n",	/* 381 */
	"non-ANSI trailing comma in enumerator list\n",	/* 382 */
	"empty declaration\n",	/* 383 */
	"unknown enumeration `%s'\n",	/* 384 */
	"missing prototype\n",	/* 385 */
	"static function %s is never used\n" 	/* 386 */
	,
/* strings from D:\LCC\SRC44\DAG.C */
	" possible usage of %s before definition\n",	/* 387 */
	"possible usage of %s before definition\n",	/* 388 */
	"node'%d printed above\n" 	/* 389 */
	,
/* strings from D:\LCC\SRC44\CV.C */
	"Unknown type %s (%d) when generating debug info\n",	/* 390 */
	"bad synch in debug info\n" 	/* 391 */
	,
/* strings from D:\LCC\SRC44\ASM.C */
	"virtual memory exceeded",	/* 392 */
	"Internal error %d\t",	/* 393 */
	"Internal error %d\t",	/* 394 */
	"Warning %d\t",	/* 395 */
	"Write error. Disk Full?\n",	/* 396 */
	"Internal error nbytes=%d\n",	/* 397 */
	"*****\nTotal collision char %c\n",	/* 398 */
	"No such instruction %s\n",	/* 399 */
	"incorrect char %c\n",	/* 400 */
	"Symbol %s has all flags\n",	/* 401 */
	"Symbol %s has all flags\n",	/* 402 */
	"Can't create the output file %s",	/* 403 */
	"relocation to %s eliminated\n" 	/* 404 */
	,
/* strings from D:\LCC\SRC44\ANALYSIS.C */
	"Overflow in jump node table",	/* 405 */
	"Overflow in number of successors\n",	/* 406 */
	"Overflow in number of successors\n",	/* 407 */
	"Assignment through pointer ",	/* 408 */
	"Array/struct ",	/* 409 */
	"constant %s ",	/* 410 */
	"static data %s\n",	/* 411 */
	"PUSH",	/* 412 */
	"Table %s ",	/* 413 */
	"static data _$%s ",	/* 414 */
	"Function arguments:\n",	/* 415 */
	"addressed ",	/* 416 */
	"Local variables:\n",	/* 417 */
	"addressed ",	/* 418 */
	"Best three symbols to register: ",	/* 419 */
	"Disjoint variables %s [%4d] (%d %d) %s [%4d] (%d %d)\n",	/* 420 */
	"Invalid register number",	/* 421 */
	"Overflow in switch\n",	/* 422 */
	"l == 0?????\n",	/* 423 */
	"Label _$%s not changed!!!!\n" 	/* 424 */
	,
/* strings from D:\LCC\SRC44\ALLOC.C */
	"insufficient memory\n",	/* 425 */
	"insufficient memory\n" 	/* 426 */
	,
/* added to main.c */
	"Invalid alignment %d ignored\n", /* 427 */
	"Incorrect argument %s\n",		/* 428 */
/* added to decl.c */
	 "old-style function definition for '%s'\n",	/* 429 */
	 "`%t %s()' is a non-ANSI definition\n",	/* 430 */
	 "`%s' is a non-ANSI definition\n",			/* 431 */
/* added to ncpp.c */
	"#warning directive: %r",					/* 432 */
/* added to w32incl.c */
	"expression too complicated\n",				/* 433 */
/* added to asm.c */
	"asm: label %s: redefined\n",				/* 434 */
	"density",									/* 435 */
	"Floating point constant expected in 'density' pragma. Ignored.", /* 436 */
	"__func__ is valid only within function scope\n",	/*437 */
};
