%{
enum { EAX=0, ECX=1, EDX=2, EBX=3, ESI=6, EDI=7 };
#include "c.h"
#define NODEPTR_TYPE Node
#define OP_LABEL(p) ((p)->op)
#define LEFT_CHILD(p) ((p)->kids[0])
#define RIGHT_CHILD(p) ((p)->kids[1])
#define STATE_LABEL(p) ((p)->x.state)
static void address     ARGS((Symbol, Symbol, int));
static void blkfetch    ARGS((int, int, int, int));
static void blkloop     ARGS((int, int, int, int, int, int[]));
static void blkstore    ARGS((int, int, int, int));
static int  ckstack     ARGS((Node, int));
static void defaddress  ARGS((Symbol));
static void defconst    ARGS((int, Value));
static void defstring   ARGS((int, char *,int));
static void defsymbol   ARGS((Symbol));
static void doarg       ARGS((Node));
static void emit0       ARGS((Node));
static void emit2       ARGS((Node));
static void export      ARGS((Symbol));
static void clobber     ARGS((Node));
static void function    ARGS((Symbol, Symbol [], Symbol [], int));
static void global      ARGS((Symbol));
static void import      ARGS((Symbol));
static void local       ARGS((Symbol));
static void progbeg     ARGS((int, char **));
static void progend     ARGS((void));
static void segment     ARGS((int));
static void space       ARGS((int));
static void target      ARGS((Node));
static int memop ARGS((Node));
static int hasargs ARGS((Node));
#ifndef ASM_LIB
static int sametree ARGS((Node, Node));
#else
extern int sametree ARGS((Node,Node));
#endif
static int iscon16(Node);
static int immediateOpShort(Node);
static int iszero(Node);
static int incrmem(Node);
Symbol charreg[32], shortreg[32], intreg[32];
static Symbol fltreg[32];
int cseg;
static int dequal(Node,int);
static int fequal(Node,int);
static Symbol quo, rem;

%}
%start stmt
%term CNSTC=	19
%term CNSTD=	18
%term CNSTF=	17
%term CNSTI=	21
%term CNSTP=	24
%term CNSTS=	20
%term CNSTU=	23
%term CNSTL=	22
%term ARGB=	42
%term ARGD=	34
%term ARGF=	33
%term ARGI=	37
%term ARGP=	40
%term ARGL=	38
%term ASGNB=	58
%term ASGNC=	51
%term ASGND=	50
%term ASGNF=	49
%term ASGNI=	53
%term ASGNS=	52
%term ASGNP=	56
%term ASGNL=	54
%term INDIRB=	74
%term INDIRC=	67
%term INDIRD=	66
%term INDIRF=	65
%term INDIRI=	69
%term INDIRS=	68
%term INDIRL=	70
%term INDIRP=	72
%term CVC=	80
%term CVCI=	85
%term CVCU=	87
%term CVD=	96
%term CVDF=	97
%term CVDI=	101
%term CVDL=	102
;;
;;%term CVF=	112
;;
%term CVFD=	114
;;
;;%term CVI=	128
;;
%term CVIC=	131
%term CVID=	130
%term CVIS=	132
%term CVIL=	134
;;
;; discontinued
;;   %term CVIU=135
;;   %term CVUI=   181
;;   %term CVPU=151
;;   %term = CVUI=181
;;   %term CVUP=184
;;
;;%term CVP=	144
;;
;;%term CVS=	160
;;
%term CVSI=	165
%term CVSU=	167
;;
;;%term CVU=	176
;;
%term CVUD=     178
%term CVUC=	179
%term CVUL=	182
%term CVUS=	180
;;
;;%term NEG=	192
;;
%term NEGD=	194
%term NEGF=	193
%term NEGI=	197
%term NEGL=	198
;;
;;%term CALL=	208
;;
%term CALLB=	218
%term CALLD=	210
%term CALLF=	209
%term CALLI=	213
%term CALLV=	217
%term CALLL=	214
;;
;;%term LOAD=	224
;;
;;%term LOADB=	234
;;
%term LOADC=	227
%term LOADD=	226
%term LOADF=	225
%term LOADI=	229
%term LOADP=	232
%term LOADS=	228
%term LOADU=	231
;;
;;%term RET=	240
;;
%term RETD=	242
%term RETL=	246
%term RETF=	241
%term RETI=	245
;;
;;%term ADDRG=	256
;;
%term ADDRGP=	264
;;
;;%term ADDRF=	272
;;
%term ADDRFP=	280
;;
;;%term ADDRL=	288
;;
%term ADDRLP=	296
%term ADDD=	306
%term ADDF=	305
%term ADDI=	309
%term ADDP=	312
%term ADDU=	311
%term ADDL=	310
%term SUBD=	322
%term SUBF=	321
%term SUBI=	325
%term SUBP=	328
%term SUBU=	327
%term SUBL=	326
%term LSHI=	341
%term LSHU=	343
%term LSHL=	342
%term MODI=	357
%term MODU=	359
%term MODL=	358
%term RSHI=	373
%term RSHU=	375
%term RSHL=	374
%term BANDU=	391
%term BANDL=	390
%term BCOML=	406
%term BCOMU=	407
%term BORL=	422
%term BORU=	423
%term BXORL=	438
%term BXORU=	439
%term DIVD=	450
%term DIVF=	449
%term DIVI=	453
%term DIVL=	454
%term DIVU=	455
%term MULD=	466
%term MULF=	465
%term MULI=	469
%term MULL=	470
%term MULU=	471
%term EQD=	482
%term EQF=	481
%term EQLO=	486
%term EQI=	485
%term GED=	498
%term GEF=	497
%term GEI=	501
%term GEU=	503
%term GEL=	502
%term GTD=	514
%term GTF=	513
%term GTI=	517
%term GTU=	519
%term GTL=	518
%term LED=	530
%term LEF=	529
%term LEI=	533
%term LEL=	534
%term LEU=	535
%term LTD=	546
%term LTF=	545
%term LTI=	549
%term LTL=	550
%term LTU=	551
%term NED=	562
%term NEF=	561
%term NEI=	565
%term NEL=	566
%term JUMPI=	581
%term JUMPV=	585
%term LABELV=	601
%term CVLI=	613
%term CVLD=	610
%term VREGP=	616
%%

reg: INDIRC(VREGP)	"# read register\n"
reg: INDIRI(VREGP)	"# read register\n"
reg: INDIRP(VREGP)	"# read register\n"
reg: INDIRS(VREGP)	"# read register\n"
freg: INDIRD(VREGP)	"# read register\n"
freg: INDIRF(VREGP)	"# read register\n"
stmt: ASGNC(VREGP,reg)	"# write register\n"
stmt: ASGNI(VREGP,reg)	"# write register\n"
stmt: ASGNP(VREGP,reg)	"# write register\n" 

stmt: ASGNS(VREGP,reg)	"# write register\n"
stmt: ASGND(VREGP,freg)	"# write register\n"
stmt: ASGNF(VREGP,freg)	"# write register\n"
con: CNSTC	"$%a"
con: CNSTI	"$%a"
con: CNSTP	"$%a"
con: CNSTS	"$%a"
con: CNSTU	"$%a"
stmt: reg	""
stmt: freg	""
;;reg: CVIU(reg)  "%0"  notarget(a)
;;reg: CVPU(reg)  "%0"  notarget(a)
;;reg: CVUI(reg)  "%0"  notarget(a)
;;reg: CVUP(reg)  "%0"  notarget(a)

acon: ADDRGP	"%a"
acon: CNSTC	"%a"
acon: CNSTI	"%a"
acon: CNSTP	"%a"
acon: CNSTS	"%a"
acon: CNSTU	"%a"

baseaddr: ADDRGP	"%a"
base: reg   	    	"(%0)"
base: ADDI(reg,acon)	"%1(%0)"
base: ADDP(reg,acon)	"%1(%0)"
base: ADDU(reg,acon)	"%1(%0)"
base: ADDRFP		"%a(%%ebp)"
base: ADDRLP		"%a(%%ebp)"

con1: CNSTI	"1"	(a->syms[0]->u.c.v.i == 1 ? 0 : LBURG_MAX)
con1: CNSTU	"1"	(a->syms[0]->u.c.v.u == 1 ? 0 : LBURG_MAX)

icon: CNSTI	"2"	(a->syms[0]->u.c.v.i == 1 ? 0 : LBURG_MAX)
icon: CNSTU	"2"	(a->syms[0]->u.c.v.u == 1 ? 0 : LBURG_MAX)
icon: CNSTI	"4"	(a->syms[0]->u.c.v.i == 2 ? 0 : LBURG_MAX)
icon: CNSTU	"4"	(a->syms[0]->u.c.v.u == 2 ? 0 : LBURG_MAX)
icon: CNSTI	"8"	(a->syms[0]->u.c.v.i == 3 ? 0 : LBURG_MAX)
icon: CNSTU	"8"	(a->syms[0]->u.c.v.u == 3 ? 0 : LBURG_MAX)

index: reg              "%0"
index: LSHI(reg,icon)	"%0,%1"
index: LSHU(reg,icon)	"%0,%1"

addr: base			"%0" 1
addr: baseaddr			"%0"
addr: ADDI(index,baseaddr)	"%1(,%0)"
addr: ADDI(reg,baseaddr)	"%1(%0)"
addr: ADDI(index,reg)		"(%1,%0)"

addr: ADDP(index,baseaddr)	"%1(,%0)"
addr: ADDP(reg,baseaddr)	"%1(%0)"
addr: ADDP(reg,acon)	"%1(%0)"
addr: ADDP(index,reg)		"(%1,%0)"
addr: ADDU(index,baseaddr)	"%1(,%0)"
addr: ADDU(reg,baseaddr)	"%1(%0)"
addr: ADDU(index,reg)		"(%1,%0)"
addr: ADDU(index,acon)          "%1(,%0)"

addr: index			"(,%0)"

memb: INDIRC(addr)	"%0"
memw: INDIRS(addr)	"%0"
mem:  INDIRI(addr)	"%0" 
mem:  INDIRP(addr)	"%0"

rc5: CNSTI	"$%a"	range(a, 0, 31)
rc5: reg	"%%cl"

rc: reg		"%0"
rc: con		"%0"

mr:   reg  "%0"
mr:   mem  "%0"

mrb:   reg  "%0"
mrb:   memb  "%0"

mrw:   reg  "%0"
mrw:   memw  "%0"

mrc: mem  "%0"  1
mrc: memb  "%0"  1
mrc: memw  "%0"  1
mrc: rc   "%0"

reg: addr		"\tleal\t%0,%c\n"			5
reg: mr			"\tmovl\t%0,%c\n"			1
reg: mrb		"\tmovb\t%0,%c\n"			1
reg: mrw		"\tmovw\t%0,%c\n"			1
reg: con		"\tmovl\t%0,%c\n"			1
reg: LOADC(reg)		"\tmovb\t%0,%c\n"			move(a)
reg: LOADI(reg)		"\tmovl\t%0,%c\n"			move(a)
reg: LOADP(reg)		"\tmovl\t%0,%c\n"			move(a)
reg: LOADS(reg)		"\tmovw\t%0,%c\n"			move(a)
reg: LOADU(reg)		"\tmovl\t%0,%c\n"			move(a)
reg: ADDI(reg,mrc)	"?\tmovl\t%0,%c\n\taddl\t%1,%c\n"	1
reg: ADDP(reg,mrc)	"?\tmovl\t%0,%c\n\taddl\t%1,%c\n"	1
reg: ADDU(reg,mrc)	"?\tmovl\t%0,%c\n\taddl\t%1,%c\n"	1
reg: SUBI(reg,mrc)	"?\tmovl\t%0,%c\n\tsubl\t%1,%c\n"	1	
reg: SUBP(reg,mrc)	"?\tmovl\t%0,%c\n\tsubl\t%1,%c\n"	1
reg: SUBU(reg,mrc)	"?\tmovl\t%0,%c\n\tsubl\t%1,%c\n"	1
reg: BANDU(reg,mrc)	"?\tmovl\t%0,%c\n\tandl\t%1,%c\n"	1
reg: BORU(reg,mrc)	"?\tmovl\t%0,%c\n\torl\t%1,%c\n"	1

reg: BXORU(reg,mrc)	"?\tmovl\t%0,%c\n\txorl\t%1,%c\n"	1
reg: LSHI(reg,rc5)	"?\tmovl\t%0,%c\n\tsall\t%1,%c\n"	2
reg: LSHI(con,rc5)	"\tmovl\t%0,%c\n\tsall\t%1,%c\n"	2
reg: LSHU(reg,rc5)	"?\tmovl\t%0,%c\n\tshll\t%1,%c\n"	3
reg: LSHU(con,rc5)	"\tmovl\t%0,%c\n\tshll\t%1,%c\n"	2
reg: RSHI(reg,rc5)	"?\tmovl\t%0,%c\n\tsarl\t%1,%c\n"	2
reg: RSHU(reg,rc5)	"?\tmovl\t%0,%c\n\tshrl\t%1,%c\n"	2
reg: BCOMU(reg)		"?\tmovl\t%0,%c\n\tnotl\t%c\n"		2
reg: NEGI(reg)		"?\tmovl\t%0,%c\n\tnegl\t%c\n"		2

stmt: ASGNI(addr,ADDI(mem,con1)) "\tincl\t%1\n"		memop(a)
stmt: ASGNI(addr,ADDU(mem,con1)) "\tincl\t%1\n"		memop(a)
stmt: ASGNI(addr,ADDU(mem,rc))	"\taddl\t%2,%1\n" 	memop(a)
stmt: ASGNP(addr,ADDP(mem,con1)) "\tincl\t%1\n"		memop(a)
stmt: ASGNI(addr,SUBI(mem,con1)) "\tdecl\t%1\n"		memop(a)
stmt: ASGNI(addr,SUBI(mem,rc))	"\tsubl\t%2,%1\n"	memop(a)
stmt: ASGNI(addr,SUBU(mem,con1)) "\tdecl\t%1\n"		memop(a)
stmt: ASGNI(addr,SUBU(mem,rc))	"\tsubl\t%2,%1\n"	memop(a)
stmt: ASGNP(addr,SUBP(mem,con1))"\tdecl\t%1\n"		memop(a)
stmt: ASGNI(addr,ADDI(mem,rc))	"\taddl\t%2,%1\n"	memop(a)

stmt: ASGNI(addr,BANDU(mem,rc))	"\tandl\t%2,%1\n"  	memop(a)
stmt: ASGNI(addr,BORU(mem,rc))	"\torl\t%2,%1\n"	1+memop(a)

stmt: ASGNI(addr,BXORU(mem,rc))	"\txorl\t%2,%1\n" 	memop(a)
stmt: ASGNI(addr,BCOMU(mem))	"\tnotl\t%1\n"		memop(a)
stmt: ASGNI(addr,NEGI(mem))	"\tnegl\t%1\n"  	memop(a)
stmt: ASGNI(addr,LSHI(mem,rc5))	"\tsall\t%2,%1\n"	memop(a)
stmt: ASGNI(addr,LSHU(mem,rc5))	"\tshll\t%2,%1\n"	memop(a)
stmt: ASGNI(addr,RSHI(mem,rc5))	"\tsarl\t%2,%1\n"	memop(a)
stmt: ASGNI(addr,RSHU(mem,rc5))	"\tshrl\t%2,%1\n"	memop(a)

reg: MULI(reg,mrc)	"?\tmovl\t%0,%c\n\timull\t%1,%c\n"  14
reg: MULI(con,mr)	"\timul\t%0,%1,%c\n"	13
reg: MULU(reg,mr)	"\tmull\t%1\n"		13
reg: DIVU(reg,reg)	"\txorl\t%%edx,%%edx\n\tdivl\t%1\n"
reg: MODU(reg,reg)	"\txorl\t%%edx,%%edx\n\tdivl\t%1\n"
reg: DIVI(reg,reg)	"\tcdq\n\tidivl\t%1\n"
reg: MODI(reg,reg)	"\tcdq\n\tidivl\t%1\n"
;;
;; This type conversions have been discontinued
;;
;;reg: CVIU(reg)		"\tmovl\t%0,%c\n"	move(a)
;;reg: CVPU(reg)		"\tmovl\t%0,%c\n"	move(a)
;;reg: CVUI(reg)		"\tmovl\t%0,%c\n"	move(a)
;;reg: CVUP(reg)		"\tmovl\t%0,%c\n"	move(a)
;;
reg: CVCI(INDIRC(addr))	"\tmovsbl\t%0,%c\n"	3
reg: CVCU(INDIRC(addr))	"\tmovzbl\t%0,%c\n"	3
reg: CVSI(INDIRS(addr))	"\tmovswl\t%0,%c\n"	3
reg: CVSU(INDIRS(addr))	"\tmovzwl\t%0,%c\n"	3

reg: CVCI(reg)  "# extend\n"  3
reg: CVCU(reg)  "# extend\n"  3
reg: CVSI(reg)  "# extend\n"  3
reg: CVSU(reg)  "# extend\n"  3
reg: CVIC(reg)  "# truncate\n"  1
reg: CVIS(reg)  "# truncate\n"  1
reg: CVUC(reg)  "# truncate\n"  1
reg: CVUS(reg)  "# truncate\n"  1

mrca: mem  "%0"
mrca: rc   "%0"
mrca: ADDRGP "$%a"

stmt: ASGNC(addr,rc)	"\tmovb\t%1,%0\n"	1
stmt: ASGNI(addr,rc)	"\tmovl\t%1,%0\n"	1
stmt: ASGNP(addr,rc)	"\tmovl\t%1,%0\n"	1
stmt: ASGNS(addr,rc)	"\tmovw\t%1,%0\n"	1
stmt: ASGNB(reg,INDIRB(reg)) "\tmovl\t$%a,%%ecx\n\trep\n\tmovsb\n"
stmt: ARGI(mrca)	"\tpushl\t%0\n"  1
stmt: ARGP(mrca)	"\tpushl\t%0\n"  1
stmt: ARGB(INDIRB(reg)) "\tsubl\t$%a,%%esp\n\tmovl\t%%esp,%%edi\n\tmovl\t$%b,%%ecx\n\trep\n\tmovsb\n"

memf: INDIRD(addr)		"l\t%0"
memf: INDIRF(addr)		"s\t%0"
memf: CVFD(INDIRF(addr))	"s\t%0"
freg: memf			"\tfld%0\n"		3
stmt: ASGND(addr,freg)		"\tfstpl\t%0\n"  7
stmt: ASGNF(addr,freg)		"\tfstps\t%0\n"  7
stmt: ASGNF(addr,CVDF(freg))	"\tfstps\t%0\n"  7
stmt: ARGD(freg)		"\tsubl\t$8,%%esp\n\tfstpl\t(%%esp)\n"
stmt: ARGF(freg)		"\tsubl\t$4,%%esp\n\tfstps\t(%%esp)\n"
freg: NEGD(freg)		"\tfchs\n"
freg: NEGF(freg)		"\tfchs\n"

flt: memf	"%0"
flt: freg	"p\t%%st,%%st(1)"

freg: ADDD(freg,flt)	"\tfadd%1\n"
freg: ADDF(freg,flt)	"\tfadd%1\n"
freg: DIVD(freg,memf)	"\tfdiv%1\n"
freg: DIVD(freg,freg)	"\tfdivrp\t%%st,%%st(1)\n" 
freg: DIVF(freg,memf)	"\tfdiv%1\n"
freg: DIVF(freg,freg)	"\tfdivrp\t%%st,%%st(1)\n"
freg: MULD(freg,flt)	"\tfmul%1\n"
freg: MULF(freg,flt)	"\tfmul%1\n"
freg: SUBD(freg,memf)	"\tfsub%1\n"
freg: SUBD(freg,freg)	"\tfsubrp\t%%st,%%st(1)\n"
freg: SUBF(freg,memf)	"\tfsub%1\n"
freg: SUBF(freg,freg)	"\tfsubrp\t%%st,%%st(1)\n"
freg: CVFD(freg)  "# CVFD\n"
freg: CVDF(freg)  "\tsub\t$4,%%esp\n\tfstps (%%esp)\n\tflds (%%esp)\n\taddl $4,%%esp\n"  12

;;stmt: ASGNI(addr,CVDI(freg))  "\tpush\t%%eax\n\t.extern\t__ftol\n\tcall\t__ftol\n\tmovl\t%%eax,%0\n\tpop\t%%eax\n"  29
reg: CVDI(freg)  "\txchg\t%%eax,%c\n\t.extern\t__ftol\n\tcall\t__ftol\n\txchg\t%%eax,%c\n" 31

freg: CVID(INDIRI(addr))  "\tfildl\t%0\n"  10
freg: CVUD(INDIRI(addr))  "\tpush\t$0\n\tpush\t%0\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n"
freg: CVID(reg)  "\tpushl\t%0\n\tfildl\t(%%esp)\n\taddl\t$4,%%esp\n"  12
freg: CVUD(reg)  "\tpushl\t$0\n\tpushl\t%0\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n"

addrj: ADDRGP  "%a"
addrj: reg     "*%0"  2
addrj: mem     "*%0"  2

addrjmp: ADDRGP  "%a"
addrjmp: reg     "*%0"  2
addrjmp: mem     "*%0"  2

stmt: LABELV		"%a:\n"
stmt: JUMPV(addrjmp)	"\tjmp\t%0\n"  3
stmt: EQI(mem,rc)	"\tcmpl\t%1,%0\n\tje\t%a\n"   5
stmt: GEI(mem,rc)	"\tcmpl\t%1,%0\n\tjge\t%a\n"  5
stmt: GTI(mem,rc)	"\tcmpl\t%1,%0\n\tjg\t%a\n"   5
stmt: LEI(mem,rc)	"\tcmpl\t%1,%0\n\tjle\t%a\n"  5
stmt: LTI(mem,rc)	"\tcmpl\t%1,%0\n\tjl\t%a\n"   5
stmt: NEI(mem,rc)	"\tcmpl\t%1,%0\n\tjne\t%a\n"  5
stmt: GEU(mem,rc)	"\tcmpl\t%1,%0\n\tjae\t%a\n"  5
stmt: GTU(mem,rc)	"\tcmpl\t%1,%0\n\tja \t%a\n"  5
stmt: LEU(mem,rc)	"\tcmpl\t%1,%0\n\tjbe\t%a\n"  5
stmt: LTU(mem,rc)	"\tcmpl\t%1,%0\n\tjb \t%a\n"  5
stmt: EQI(reg,mrc)	"\tcmpl\t%1,%0\n\tje\t%a\n"   4
stmt: GEI(reg,mrc)	"\tcmpl\t%1,%0\n\tjge\t%a\n"  4
stmt: GTI(reg,mrc)	"\tcmpl\t%1,%0\n\tjg\t%a\n"   4
stmt: LEI(reg,mrc)	"\tcmpl\t%1,%0\n\tjle\t%a\n"  4
stmt: LTI(reg,mrc)	"\tcmpl\t%1,%0\n\tjl\t%a\n"   4
stmt: NEI(reg,mrc)	"\tcmpl\t%1,%0\n\tjne\t%a\n"  4

stmt: GEU(reg,mrc)	"\tcmpl\t%1,%0\n\tjae\t%a\n"  4
stmt: GTU(reg,mrc)	"\tcmpl\t%1,%0\n\tja \t%a\n"  4
stmt: LEU(reg,mrc)	"\tcmpl\t%1,%0\n\tjbe\t%a\n"  4
stmt: LTU(reg,mrc)	"\tcmpl\t%1,%0\n\tjb \t%a\n"  4

cmpf: INDIRD(addr)		"l\t%0"
cmpf: INDIRF(addr)		"s\t%0"
cmpf: CVFD(INDIRF(addr))	"s\t%0"
cmpf: freg	"p"

stmt: EQD(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tandb\t$68,%%ah\n\tcmpb\t$64,%%ah\n\tje\t%a\n"
stmt: GED(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tjbe\t%a\n"
stmt: GTD(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tjb\t%a\n"
stmt: LED(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tjae\t%a\n"
stmt: LTD(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tja\t%a\n"
stmt: NED(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tandb\t$68,%%ah\n\tje\t%a\n" 1

stmt: EQF(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tje\t%a\n"
stmt: GEF(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tjbe\t%a\n"
stmt: GTF(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tjb\t%a\n"
stmt: LEF(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tjae\t%a\n"
stmt: LTF(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tsahf\n\tja\t%a\n"
stmt: NEF(cmpf,freg)	"\tfcomp%0\n\tfstsw %%ax\n\tandb\t$68,%%ah\n\tje\t%a\n"

reg:  CALLI(addrj)  "\tcall\t%0\n\taddl\t$%a,%%esp\n"	hasargs(a)
reg:  CALLI(addrj)  "\tcall\t%0\n"			1

stmt: CALLV(addrj)  "\tcall\t%0\n\taddl\t$%a,%%esp\n"	hasargs(a)
stmt: CALLV(addrj)  "\tcall\t%0\n"			1

freg: CALLF(addrj)  "\tcall\t%0\n\taddl\t$%a,%%esp\n"	15+hasargs(a)
freg: CALLF(addrj)  "\tcall\t%0\n"			15+1

stmt: CALLF(addrj)  "\tcall\t%0\n\taddl\t$%a,%%esp\n\tfstp\t%%st(0)\n"	hasargs(a)
stmt: CALLF(addrj)  "\tcall\t%0\n\tfstp\t%%st(0)\n"			1

freg: CALLD(addrj)  "\tcall\t%0\n\taddl\t$%a,%%esp\n"	15+hasargs(a)
freg: CALLD(addrj)  "\tcall\t%0\n"			15+1

stmt: CALLD(addrj)  "\tcall\t%0\n\taddl\t$%a,%%esp\n\tfstp\t%%st(0)\n"	hasargs(a)
stmt: CALLD(addrj)  "\tcall\t%0\n\tfstp\t%%st(0)\n"			1

stmt: RETI(reg)  "# ret\n" 1
stmt: RETF(freg)  "# retf\n"
stmt: RETD(freg)  "# retd\n"
;;
;; This part was added for the lcc-win32 x86 machine description.
;; In general this rules will NOT work with the standard front end because
;; they do not take into account the vacuous conversions: CVUP CVIU and all
;; others. I eliminated them in the front end since if we maintained them
;; this already long machine description would be completely unmanageable.
;; The number of rules increases exponentially when those conversions are
;; present. It is a simple modification of one line in dag.c
;;
;; This rule avoids using a register to hold an immediate constant
reg: SUBI(con,mr)	"\tmovl\t%1,%c\n\tsubl\t%0,%c\n\tnegl\t%c\n"
;; The same for shifts
reg: LSHI(con,rc5)	"\tmovl\t%0,%c\n\tsall\t%1,%c\n"
;; The same for character assignments
stmt: ASGNC(addr,CVIC(con)) "\tmovb\t%1,%0\n"
;;
;; This rules have the general form:
;; ASGNX(addr,OPERATION(INDIRX(addr),constant))
;; Note that both addresses SHOULD BE THE SAME. This test is taken care
;; of by the function 'incrmem'.
;;
stmt: ASGNP(addr,ADDP(INDIRP(addr),acon)) "\taddl\t$%2,%0\n" incrmem(a)
stmt: ASGNP(addr,SUBP(INDIRP(addr),acon)) "\tsubl\t$%2,%0\n" incrmem(a)
stmt: ASGNP(addr,SUBP(INDIRP(addr),reg)) "\tsubl\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,ADDI(INDIRI(addr),rc))  "\taddl\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,ADDU(INDIRI(addr),rc))  "\taddl\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,SUBI(INDIRI(addr),rc))  "\tsubl\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,SUBU(INDIRI(addr),rc))  "\tsubl\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,BANDU(INDIRI(addr),rc)) "\tandl\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,BORU(INDIRI(addr),rc))  "\torl\t%2,%0\n"  incrmem(a)
stmt: ASGNI(addr,LSHI(INDIRI(addr),con))  "\tsall\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,LSHU(INDIRI(addr),con))  "\tshll\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,RSHI(INDIRI(addr),con))  "\tsarl\t%2,%0\n" incrmem(a)
stmt: ASGNI(addr,RSHU(INDIRI(addr),con))  "\tshrl\t%2,%0\n" incrmem(a)
;;
;; This rules simplify unnecessary conversions from 1. Note that the
;; test for the tree shape is done by a different function since the
;; trees are different.
;;

stmt: ASGNS(addr,CVIS(ADDI(CVSI(INDIRS(addr)),con1))) "\tincw\t%0\n" immediateOpShort(a)
stmt: ASGNS(addr,CVIS(SUBI(CVSI(INDIRS(addr)),con1))) "\tdecw\t%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVIC(ADDI(CVCI(INDIRC(addr)),con1))) "\tincb\t%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVIC(SUBI(CVCI(INDIRC(addr)),con1))) "\tdecb\t%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVUC(SUBI(CVCU(INDIRC(addr)),con1))) "\tdecb\t%0\n" immediateOpShort(a)
stmt: ASGNS(addr,CVUS(SUBI(CVSU(INDIRS(addr)),con1))) "\tdecw\t%0\n" immediateOpShort(a)
stmt: ASGNS(addr,CVUS(ADDI(CVSU(INDIRS(addr)),con1))) "\tincw\t%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVUC(ADDI(CVCU(INDIRC(addr)),con1))) "\tincb\t%0\n" immediateOpShort(a)
;;
;; This rules act directly between a constant and a memory location. Similar
;; to the rules above
;;

;;
;; First short convertions
;;
stmt: ASGNS(addr,CVIS(SUBI(CVSI(INDIRS(addr)),con)))  "\tsubw\t%2,%0\n" 1+immediateOpShort(a)
stmt: ASGNS(addr,CVIS(ADDI(CVSI(INDIRS(addr)),con)))  "\taddw\t%2,%0\n" 1+immediateOpShort(a)
stmt: ASGNS(addr,CVIS(BANDU(CVSI(INDIRS(addr)),con))) "\tandw\t%2,%0\n" immediateOpShort(a)
stmt: ASGNS(addr,CVIS(BORU(CVSI(INDIRS(addr)),con)))  "\torw\t%2,%0\n"  immediateOpShort(a)
stmt: ASGNS(addr,CVIS(LSHI(CVSI(INDIRS(addr)),con)))  "\tsalw\t%2,%0\n" immediateOpShort(a)
stmt: ASGNS(addr,CVIS(RSHI(CVSI(INDIRS(addr)),con)))  "\tsarw\t%2,%0\n" immediateOpShort(a)

stmt: ASGNS(addr,CVUS(SUBI(CVSU(INDIRS(addr)),con)))  "\tsubw\t%2,%0\n" 1+immediateOpShort(a)
stmt: ASGNS(addr,CVUS(ADDI(CVSU(INDIRS(addr)),con)))  "\taddw\t%2,%0\n" 1+immediateOpShort(a)
stmt: ASGNS(addr,CVUS(BANDU(CVSU(INDIRS(addr)),con))) "\tandw\t%2,%0\n" immediateOpShort(a)
stmt: ASGNS(addr,CVUS(BORU(CVSU(INDIRS(addr)),con)))  "\torw\t%2,%0\n"  immediateOpShort(a)
stmt: ASGNS(addr,CVUS(LSHI(CVSU(INDIRS(addr)),con)))  "\tsalw\t%2,%0\n" immediateOpShort(a)
stmt: ASGNS(addr,CVUS(RSHI(CVSU(INDIRS(addr)),con)))  "\tshrw\t%2,%0\n" immediateOpShort(a)
stmt: ASGNS(addr,CVIS(reg)) "\tmovw\t%1,%0\n"
stmt: ASGNS(addr,CVUS(reg)) "\tmovw\t%1,%0\n"

;; Then character conversions
;;
stmt: ASGNC(addr,CVUC(SUBI(CVCU(INDIRC(addr)),con)))  "\tsubb\t%2,%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVUC(ADDI(CVCU(INDIRC(addr)),con)))  "\taddb\t%2,%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVUC(BANDU(CVCU(INDIRC(addr)),con))) "\tandb\t%2,%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVUC(BORU(CVCU(INDIRC(addr)),con)))  "\torb\t%2,%0\n"  immediateOpShort(a)
stmt: ASGNC(addr,CVUC(LSHI(CVCU(INDIRC(addr)),con)))  "\tsalb\t%2,%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVUC(RSHI(CVCU(INDIRC(addr)),con)))  "\tshrb\t%2,%0\n" immediateOpShort(a)

stmt: ASGNC(addr,CVIC(SUBI(CVCI(INDIRC(addr)),con)))  "\tsubb\t%2,%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVIC(ADDI(CVCI(INDIRC(addr)),con)))  "\taddb\t%2,%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVIC(BANDU(CVCI(INDIRC(addr)),con))) "\tandb\t%2,%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVIC(BORU(CVCI(INDIRC(addr)),con)))  "\torb\t%2,%0\n"  immediateOpShort(a)
stmt: ASGNC(addr,CVUC(BORU(CVCU(INDIRC(addr)),con)))  "\torl\t%2,%0\n"  1+immediateOpShort(a)
stmt: ASGNC(addr,CVIC(LSHI(CVCI(INDIRC(addr)),con)))  "\tsalb\t%2,%0\n" immediateOpShort(a)
stmt: ASGNC(addr,CVIC(RSHI(CVCI(INDIRC(addr)),con)))  "\tsarb\t%2,%0\n" immediateOpShort(a)

;; This new terminals should be introduced at the beginning of the file.
;; Due to an internal 'hack' in 'emitasm', the integer that represents
;; a rule can't change, so I wrote all new rules later on. I will change that
;; when I have a little time...

zero: CNSTI     "0"     ((a->syms[0]->u.c.v.i == 0)?0:LBURG_MAX)
zero: CNSTU     "0"     ((a->syms[0]->u.c.v.u == 0)?0:LBURG_MAX)


;; Comparisons with zero
;;
stmt: EQI(BANDU(mr,con),zero) "\ttestl\t%1,%0\n\tje\t%a\n" 3
stmt: NEI(BANDU(mr,con),zero) "\ttestl\t%1,%0\n\tjne\t%a\n"
stmt: NEI(BANDU(CVCI(mr),con),zero) "\ttestb\t%1,%0\n\tjne\t%a\n"

stmt: EQI(BANDU(CVSI(INDIRS(addr)),con),zero) "\ttestw\t%1,%0\n\tje\t%a\n"
stmt: NEI(BANDU(CVSI(INDIRS(addr)),con),zero) "\ttestw\t%1,%0\n\tjne\t%a\n"
stmt: EQI(BANDU(CVSU(INDIRS(addr)),con),zero) "\ttestw\t%1,%0\n\tje\t%a\n"
stmt: NEI(BANDU(CVSU(INDIRS(addr)),con),zero) "\ttestw\t%1,%0\n\tjne\t%a\n"
stmt: NEI(BANDU(CVCU(INDIRC(addr)),con),zero) "\ttestb\t%1,%0\n\tjne\t%a\n"
stmt: EQI(BANDU(CVCI(INDIRC(addr)),con),zero) "\ttestb\t%1,%0\n\tje\t%a\n"
stmt: EQI(BANDU(CVCU(INDIRC(addr)),con),zero) "\ttestb\t%1,%0\n\tje\t%a\n"
;;
;; this beauty results when you do the C statement:
;; if (isdigit(c))
;;
stmt: NEI(BANDU(INDIRI(addr),con),zero) "\ttestl\t%1,%0\n\tjne\t%a\n" 2
stmt: EQI(BANDU(INDIRI(addr),con),zero) "\ttestl\t%1,%0\n\tje\t%a\n" 1
;;
stmt: NEI(BANDU(INDIRC(addr),con),zero) "\ttestb\t%1,%0\n\tjne\t%a\n"
stmt: EQI(BANDU(reg,con),zero) "\ttestl\t%1,%0\n\tje\t%a\n" 1
;;stmt: EQI(BANDU(reg,con16),zero) "\ttestw\t%1,%0\n\tje\t%a\n" 
stmt: NEI(BANDU(reg,con),zero) "\ttestl\t%1,%0\n\tjne\t%a\n"

;; Comparing directly a memory location to an immediate constant
;;
stmt: NEI(CVSI(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjne\t%a\n"
stmt: NEI(CVSU(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjne\t%a\n"
stmt: LEI(CVSI(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjle\t%a\n"
stmt: LEI(CVSU(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjbe\t%a\n"
stmt: LTI(CVSI(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjl\t%a\n"
stmt: LTI(CVSU(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjb\t%a\n"
stmt: GTI(CVSI(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjg\t%a\n"
stmt: GTU(CVSU(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tja\t%a\n"
stmt: GEI(CVSI(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjge\t%a\n"
stmt: GEI(CVSU(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tjae\t%a\n"
stmt: EQI(CVSI(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tje\t%a\n"
stmt: EQI(CVSU(INDIRS(addr)),con) "\tcmpw\t%1,%0\n\tje\t%a\n"

stmt: NEI(CVCI(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjne\t%a\n"
stmt: NEI(CVCU(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjne\t%a\n"
;;
;; immediate comparisons of a byte register with a constant
;; without any conversions
;;
stmt: NEI(CVCI(reg),con) "\tcmpb\t%1,%0\n\tjne\t%a\n"
stmt: NEI(CVCU(reg),con) "\tcmpb\t%1,%0\n\tjne\t%a\n"
stmt: EQI(CVCI(reg),con) "\tcmpb\t%1,%0\n\tje\t%a\n"
stmt: EQI(CVCU(reg),con) "\tcmpb\t%1,%0\n\tje\t%a\n"
stmt: EQI(CVCI(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tje\t%a\n"
stmt: EQI(CVCU(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tje\t%a\n"
stmt: LEI(CVCI(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjle\t%a\n"
stmt: LEU(CVCU(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjbe\t%a\n"
stmt: LTI(CVCI(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjl\t%a\n"
stmt: LTU(CVCU(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjb\t%a\n"
stmt: GTI(CVCI(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjg\t%a\n"
stmt: GTU(CVCU(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tja\t%a\n"
stmt: GEI(CVCI(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjge\t%a\n"
stmt: GEU(CVCU(INDIRC(addr)),con) "\tcmpb\t%1,%0\n\tjae\t%a\n"

base: ADDP(ADDRGP,acon) "%a+%1"
;;
;; This happens in the C idiom:
;; if (!somfn())
;; when somfn returns an unsigned short.
;;
stmt: NEI(CVSU(CVUS(reg)),zero)   "\torw\t%0,%0\n\tjne\t%a\n"
stmt: EQI(CVSU(CVUS(reg)),zero)   "\torw\t%0,%0\n\tje\t%a\n"
stmt: NEI(CVSI(CVIS(reg)),zero)   "\torw\t%0,%0\n\tjne\t%a\n"
stmt: EQI(CVSI(CVIS(reg)),zero)   "\torw\t%0,%0\n\tjne\t%a\n"

;; Some floating point constnts can be generated directly by the
;; machine. This is not faster but should save space in the data
;; segment once I convice the front end not to generate them.

dcon1: CNSTD "\tfld1\n" dequal(a,1)
dcon1: CNSTL "\tfld1\n" dequal(a,1)
dcon0: CNSTD "\tfldz\n" dequal(a,0)
dcon0: CNSTL "\tfldz\n" dequal(a,0)
dcon1: CNSTF "\tfld1\n" fequal(a,1)
dcon0: CNSTF "\tfldz\n" fequal(a,0)
freg: dcon1 "%0"
freg: dcon0 "%0"

;; This floating point operations were missing from the machine
;; description.

freg: DIVD(freg,CVID(INDIRI(addr))) "\tfidivl\t%1\n"
freg: DIVD(CVID(INDIRI(addr)),freg) "\tfidivrl\t%0\n"
freg: DIVD(freg,CVID(CVSI(INDIRS(addr)))) "\tfidivs\t%1\n"
freg: DIVD(CVID(CVSI(INDIRS(addr))),freg) "\tfidivrs\t%0\n"
freg: MULD(freg,CVID(INDIRI(addr))) "\tfimull\t%1\n"
freg: MULD(CVID(INDIRI(addr)),freg) "\tfimull\t%0\n"
freg: MULD(freg,CVID(CVSI(INDIRS(addr)))) "\tfimuls\t%1\n"
freg: SUBD(freg,CVID(INDIRI(addr))) "\tfisubl\t%1\n"
freg: SUBD(CVID(INDIRI(addr)),freg) "\tfisubrl\t%0\n"
freg: SUBD(freg,CVID(CVSI(INDIRS(addr)))) "\tfisubs\t%1\n"
freg: SUBD(CVID(CVSI(INDIRS(addr))),freg) "\tfisubrs\t%0\n"
freg: ADDD(freg,CVID(INDIRI(addr))) "\tfiaddl\t%1\n"
freg: ADDD(CVID(INDIRI(addr)),freg) "\tfiaddl\t%0\n"
freg: ADDD(freg,CVID(CVSI(INDIRS(addr)))) "\tfiadds\t%1\n"
freg: ADDD(freg,CVFD(INDIRF(addr))) "\tfdivs\t%1\n"
freg: SUBD(freg,CVFD(INDIRF(addr))) "\tfsubs\t%1\n"
freg: MULD(freg,CVFD(INDIRF(addr))) "\tfmuls\t%1\n"
freg: DIVD(freg,CVFD(INDIRF(addr))) "\tfdivs\t%1\n"
freg: LOADD(memf) "\tfld%0\n"

;;
;; Comparisons between byte/short reg with byte/short memory
;;
stmt: EQI(CVCU(reg),CVCU(INDIRC(addr))) "\tcmpb\t%1,%0\n\tje\t%a\n"
stmt: EQI(CVCI(reg),CVCI(INDIRC(addr))) "\tcmpb\t%1,%0\n\tje\t%a\n"
stmt: NEI(CVCU(reg),CVCU(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjne\t%a\n"
stmt: NEI(CVCI(reg),CVCI(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjne\t%a\n"
stmt: EQI(CVSI(reg),CVSI(INDIRS(addr))) "\tcmpw\t%1,%0\n\tje\t%a\n"
stmt: EQI(CVSU(reg),CVSU(INDIRS(addr))) "\tcmpw\t%1,%0\n\tje\t%a\n"
stmt: NEI(CVSU(reg),CVSU(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjne\t%a\n"
stmt: NEI(CVSI(reg),CVSI(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjne\t%a\n"
stmt: LEI(CVCU(reg),CVCU(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjbe\t%a\n"
stmt: LEI(CVCI(reg),CVCI(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjle\t%a\n"
stmt: LTU(CVCU(reg),CVCU(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjb\t%a\n"
stmt: LTI(CVCI(reg),CVCI(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjl\t%a\n"
stmt: GTI(CVCI(reg),CVCI(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjg\t%a\n"
stmt: GTU(CVCU(reg),CVCU(INDIRC(addr))) "\tcmpb\t%1,%0\n\tja\t%a\n"
stmt: GEI(CVCI(reg),CVCI(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjge\t%a\n"
stmt: GEI(CVCU(reg),CVCU(INDIRC(addr))) "\tcmpb\t%1,%0\n\tjae\t%a\n"
stmt: LEU(CVSU(reg),CVSU(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjbe\t%a\n"
stmt: LEI(CVSI(reg),CVSI(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjle\t%a\n"
stmt: LTI(CVSI(reg),CVSI(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjl\t%a\n"
stmt: LTU(CVSU(reg),CVSU(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjb\t%a\n"
stmt: GTI(CVSI(reg),CVSI(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjg\t%a\n"
stmt: GTU(CVSU(reg),CVSU(INDIRS(addr))) "\tcmpw\t%1,%0\n\tja\t%a\n"
stmt: GEI(CVSI(reg),CVSI(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjge\t%a\n"
stmt: GEU(CVSU(reg),CVSU(INDIRS(addr))) "\tcmpw\t%1,%0\n\tjae\t%a\n"

;;
;; This rule avoids a sequence of instructions like:
;; movsbl  (,%edi),%edx
;; movzbl  %dl,%edx
;; and replaces them for the shorter
;; movzbl  (,%edi),%edx
reg: CVCU(CVUC(CVCI(INDIRC(addr)))) "\tmovzbl\t%0,%c\n"
;;
;; This rule avoids a spurious register assignment when returning the
;; result of a function call.
stmt: RETI(LOADI(reg)) "?\tmovl\t%0,%%eax\n"
;; other RETI rules
stmt: RETI(ADDI(reg,acon)) "\tleal\t%1(%0),%%eax\n"
stmt: RETI(ADDP(reg,acon)) "\tleal\t%1(%0),%%eax\n"
stmt: RETI(zero) "\txor\t%%eax,%%eax\n"
;;
;; 3 adds in one instruction
;;
reg: ADDP(reg,ADDP(reg,acon)) "\tleal\t%2(%0,%1),%c\n"
addr: ADDP(reg,ADDP(reg,acon)) "%2(%0,%1)"
reg: ADDP(ADDP(reg,acon),reg) "\tleal\t%1(%0,%2),%c\n"
addr: ADDP(ADDP(reg,acon),reg) "%1(%0,%2)"
reg: ADDP(ADDP(reg,reg),acon) "\tleal\t%2(%0,%1),%c\n"
addr: ADDP(ADDP(reg,reg),acon) "%2(%0,%1)"
;;
;; The general form of the 'lea' instruction
;;
reg:  ADDP(ADDP(LSHI(reg,icon),reg),acon) "\tleal\t%3(%2,%0,%1),%c\n"
reg:  ADDP(ADDI(LSHI(reg,icon),reg),acon) "\tleal\t%3(%2,%0,%1),%c\n"
addr: ADDP(ADDI(LSHI(reg,icon),reg),acon) "%3(%2,%0,%1)"
addr: ADDP(ADDP(LSHI(reg,icon),reg),acon) "%3(%2,%0,%1)"
addr: ADDP(ADDP(index,reg),baseaddr) "%2(%1,%0)"
addr: ADDP(baseaddr,ADDP(index,reg)) "%0(%2,%1)"
addr: ADDU(ADDU(reg,reg),baseaddr) "%2(%1,%0)"
addr: ADDP(ADDI(LSHI(reg,icon),acon),reg) "%2(%3,%0,%1)"
reg:  ADDP(ADDI(LSHI(reg,icon),acon),reg) "\tleal\t%2(%3,%0,%1),%c\n"
reg:  ADDP(LSHI(reg,icon),reg) "\tleal\t(%2,%0,%1),%c\n"
addr: ADDP(LSHI(reg,icon),reg) "(%2,%0,%1)"
reg:  ADDP(LSHI(reg,icon),ADDP(reg,acon)) "\tleal\t%3(%2,%0,%1),%c\n"
addr: ADDP(LSHI(reg,icon),ADDP(reg,acon)) "%3(%2,%0,%1)"

reg: ADDI(reg,ADDI(reg,acon)) "\tleal\t%2(%0,%1),%c\n"
reg: ADDP(ADDI(reg,acon),reg) "\tleal\t%1(%0,%2),%c\n"
addr: ADDP(ADDI(reg,acon),reg) "%1(%0,%2)"
reg: ADDI(ADDI(reg,acon),reg) "\tleal\t%1(%0,%2),%c\n"
reg: ADDI(ADDI(reg,reg),acon) "\tleal\t%2(%0,%1),%c\n"
;;
;; int 64 support
;;
;; assignment
stmt: ASGNL(INDIRL(addr),freg) "\tfistpq\t%0\n"
stmt: ASGNL(INDIRL(addr),rpair) "\tmovl\t%%eax,%0\n\tleal\t%0,%%eax\n\tmovl\t%%edx,4(%%eax)\n" 3
stmt: ASGNL(addr,freg) "\tfistpq\t%0\n"
stmt: ASGNL(addr,rpair) "\tmovl\t%%eax,%0\n\tleal\t%0,%%eax\n\tmovl\t%%edx,4(%%eax)\n" 3
;;
;; += and +- operations
;;
;;stmt: ASGNL(addr,ADDL(INDIRL(addr),rpair)) "\tleal\t%0,%%ecx\n\taddl\t%%eax,(%%ecx)\n\taddl\t%%edx,4(%%ecx)\n" (LEFT_CHILD(a) != NULL && LEFT_CHILD(a) == LEFT_CHILD(LEFT_CHILD(RIGHT_CHILD(a))))?3:LBURG_MAX
;;stmt: ASGNL(addr,SUBL(INDIRL(addr),rpair)) "\tleal\t%1,%%ecx\n\tsubl\t%%eax,(%%ecx)\n\tsbb\t%%edx,4(%%ecx)\n" (LEFT_CHILD(a) != NULL && LEFT_CHILD(a) == LEFT_CHILD(LEFT_CHILD(RIGHT_CHILD(a))))?3:LBURG_MAX
;;
;; constants
;;
freg: CVIL(con1) "\tfld1\n" 2
freg: CVIL(zero) "\tfldz\n" 2
rpair: CVIL(rc) "\tmovl\t%0,%%eax\n\tcdq\n"
rpair: CVUL(rc) "\tmovl\t%0,%%eax\n\txor\t%%edx,%%edx\n"
;;
;; moving memory to EAX:EDX
;;
rpair:INDIRL(addr) "\tmovl\t%0,%%eax\n\tleal\t%0,%%edx\n\tmovl\t4(%%edx),%%edx\n" 4
;;
;; moving EAX:EDX to st(0)
;;
freg: INDIRL(rpair) "\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n" 6
;;
;; moving memory to st(0)
;;
freg: INDIRL(addr) "\tfildq\t%0\n"
;;
;; argument pushing
;;
stmt: ARGL(INDIRL(addr)) "\tsubl\t$8,%%esp\n\tfildq\t%0\n\tfistpq\t(%%esp)\n" 3
stmt: ARGL(freg) "\tsubl\t$8,%%esp\n\tfistpq\t(%%esp)\n" 2
stmt: ARGL(CVIL(rc)) "\tpushl\t$0\n\tpushl\t%0\n" 2
stmt: ARGL(rpair) "\tpushl\t%%edx\n\tpushl\t%%eax\n" 1
;;
;; conversions
;;
freg: CVLD(INDIRL(addr)) "\tfildq\t%0\n"
freg: CVIL(INDIRI(addr)) "\tfildl\t%0\n"
freg: CVIL(rc) "\tpush\t%0\n\tfildl\t(%%esp)\n\taddl\t$4,%%esp\n" 2
freg: CVUL(rc) "\tpush\t$0\n\tpush\t%0\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n"
reg: CVLI(freg) "\tpushl\t%c\n\tfistpl\t(%%esp)\n\tpopl\t%c\n" 2
reg: CVLI(rpair) "\tmovl\t%%eax,%c\n"
reg: CVLI(INDIRL(addr)) "\tmovl\t%0,%c\n"
;;
;; addition
;;
freg: ADDL(INDIRL(addr),CVID(INDIRI(addr))) "\tfildq\t%0\n\tfiaddl\t%1\n"
freg: ADDL(INDIRL(addr),CVIL(con1)) "\tfildq\t%0\n\tfld1\n\tfaddpl\n" 4
freg: ADDL(INDIRL(addr),freg) "\tfildq\t%0\n\tfaddpl\n" 4
freg: ADDL(freg,INDIRL(addr)) "\tfildq\t%1\n\tfaddpl\n" 4
freg: ADDL(freg,CVIL(reg)) "\tpush\t%1\n\tfiaddl\t(%%esp)\n\taddl\t$4,%%esp\n"
rpair: ADDL(addr,rpair) "\tleal\t%0,%%ecx\n\taddl\t(%%ecx),%%eax\n\taddl\t4(%%ecx),%%edx\n" 6
rpair: ADDL(INDIRL(addr),rpair) "\tleal\t%0,%%ecx\n\taddl\t(%%ecx),%%eax\n\tadc\t4(%%ecx),%%edx\n" 6
;;
;; substraction
;;
freg: SUBL(INDIRL(addr),freg) "\tfildq\t%0\n\tfsubpl\n" 1
rpair: SUBL(rpair,INDIRL(addr)) "\tleal\t%1,%%ecx\n\tsubl\t(%%ecx),%%eax\n\tsbb\t4(%%ecx),%%edx\n"
;;
;; multiplication is always done in floating point
freg: MULL(INDIRL(addr),freg) "\tfildq\t%0\n\tfmulpl\n"
freg: MULL(freg,CVIL(INDIRI(addr))) "\tfimull\t%1\n"
;;
;; division
;;
rpair: DIVL(INDIRL(addr),freg) "\t.extern\t__alldiv\n\tsub\t$16,%%esp\n\tfistpq\t8(%%esp)\n\tfildq\t%0\n\tfistpq\t(%%esp)\n\tcall\t__alldiv\n" 7
rpair: DIVL(freg,INDIRL(addr)) "\t.extern\t__alldiv\n\tsub\t$16,%%esp\n\tfistpq\t8(%%esp)\n\tfildq\t%1\n\tfistpq\t(%%esp)\n\tcall\t__alldiv\n" 7
freg: DIVL(INDIRL(addr),freg) "\t.extern\t__alldiv\n\tsub\t$16,%%esp\n\tfistpq\t8(%%esp)\n\tfildq\t%0\n\tfistpq\t(%%esp)\n\tcall\t__alldiv\n\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n" 18
freg: DIVL(freg,INDIRL(addr)) "\t.extern\t__alldiv\n\tsub\t$16,%%esp\n\tfistpq\t(%%esp)\n\tfildq\t%1\n\tfistpq\t8(%%esp)\n\tcall\t__alldiv\n\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n" 18
con32: CNSTI "32" (a->syms[0]->u.c.v.i == 32 ? 0 : LBURG_MAX)
con32: CNSTU "32" (a->syms[0]->u.c.v.u == 32 ? 0 : LBURG_MAX)
;;
;; left shift
;;
rpair: LSHL(rpair,mrc) "\t.extern\t__allshl\n\tmovl\t%1,%%ecx\n\tcall\t__allshl\n" 3
freg: LSHL(freg,mrc) "\t.extern\t__allshl\n\tmovl\t%1,%%ecx\n\tsubl\t$8,%%esp\n\tfistpq\t(%%esp)\n\tpopl\t%%eax\n\tpopl\t%%edx\n\tcall\t__allshl\n\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n" 15
freg: LSHL(INDIRL(addr),mrc) "\t.extern\t__allshl\n\tmovl\t%1,%%ecx\n\tsubl\t$8,%%esp\n\tfildq\t%0\n\tfistpq\t(%%esp)\n\tpopl\t%%eax\n\tpopl\t%%edx\n\tcall\t__allshl\n\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n" 
freg: LSHL(INDIRL(addr),INDIRL(addr)) "\t.extern\t__allshl\n\tmovl\t%1,%%ecx\n\tsubl\t$8,%%esp\n\tfildq\t%0\n\tfistpq\t(%%esp)\n\tpopl\t%%eax\n\tpopl\t%%edx\n\tcall\t__allshl\n\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n"
;;
;; right shift
;;
rpair: RSHL(rpair,mrc) "\t.extern\t__allshr\n\tmovl\t%1,%%ecx\n\tcall\t__allshr\n" 3
freg: RSHL(freg,mrc) "\t.extern\t__allshr\n\tmovl\t%1,%%ecx\n\tsubl\t$8,%%esp\n\tfistpq\t(%%esp)\n\tpopl\t%%eax\n\tpopl\t%%edx\n\tcall\t__allshr\n\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\taddl\t$8,%%esp\n" 15
rpair: RSHL(INDIRL(addr),mrc) "\t.extern\t__allshr\n\tmovl\t%1,%%ecx\n\tfildq\t%0\n\tsubl\t$8,%%esp\n\tfistpq\t(%%esp)\n\tpopl\t%%eax\n\tpopl\t%%edx\n\tcall\t__allshr\n"
rpair: RSHL(INDIRL(addr),INDIRL(addr)) "\t.extern\t__allshr\n\tmovl\t%1,%%ecx\n\tfildq\t%0\n\tsubl\t$8,%%esp\n\tfistpq\t(%%esp)\n\tpopl\t%%eax\n\tpopl\t%%edx\n\tcall\t__allshr\n" 
rpair: RSHL(INDIRL(addr),con32) "\tleal\t%0,%%eax\n\tmovl\t4(%%eax),%%eax\n\txorl\t%%edx,%%edx\n"
rpair: RSHL(rpair,con32) "\tmovl\t%%edx,%%eax\n\txorl\t%%edx,%%edx\n"
;;
;; logical operations
;;
rpair: BANDL(INDIRL(addr),rpair) "\tleal\t%0,%%ecx\n\tandl\t(%%ecx),%%eax\n\tandl\t4(%%ecx),%%edx\n"
rpair: BORL(INDIRL(addr),rpair) "\tleal\t%0,%%ecx\n\torl\t(%%ecx),%%eax\n\torl\t4(%%ecx),%%edx\n"
rpair: BXORL(INDIRL(addr),rpair) "\tleal\t%0,%%ecx\n\txorl\t(%%ecx),%%eax\n\txorl\t4(%%ecx),%%edx\n"
rpair: BCOML(rpair) "\tnotl\t%%eax\n\tnotl\t%%edx\n"

stmt: ASGNL(addr,LSHL(freg,mrc)) "\t.extern\t__allshl\n\tmovl\t%2,%%ecx\n\tsubl\t$8,%%esp\n\tfistpq\t(%%esp)\n\tpopl\t%%eax\n\tpopl\t%%edx\n\tcall\t__allshl\n\tleal\t%0,%%ecx\n\tmovl\t%%eax,(%%ecx)\n\tmovl\t%%edx,4(%%ecx)\n" 8
stmt: ASGNL(addr,LSHL(rpair,mrc)) "\t.extern\t__allshl\n\tmovl\t%2,%%ecx\n\tcall\t__allshl\n\tleal\t%0,%%ecx\n\tmovl\t%%eax,(%%ecx)\n\tmovl\t%%edx,4(%%ecx)\n" 4
;;
;; Modulo operation
;;
freg: MODL(INDIRL(addr),rc) "\tpushl\t%1\n\tfildl\t(%%esp)\n\taddl\t$4,%%esp\n\tfildq\t%0\n\tfprem\n\tfxch\t%%st(1)\n\tfstp\t%%st(0)\n"
freg: MODL(INDIRL(addr),freg) "\tfildq\t%0\n\tfprem\n\tfxch\t%%st(1)\n\tfstp\t%%st(0)\n"
freg: NEGL(freg) "\tfchs\n"
;;
;; comparisons
;;
stmt: LTL(INDIRL(addr),freg) "\tfildq\t%0\n\tfcompp\n\tfstsw\t%%ax\n\tsahf\n\tjb\t%a\n" 10
stmt: LTL(rpair,freg) "\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\tfcompp\n\tfstsw\t%%ax\n\taddl\t$8,%%esp\n\tsahf\n\tjb\t%a\n"
stmt: GEL(INDIRL(addr),freg) "\tfildq\t%0\n\tfcompp\n\tfstsw\t%%ax\n\tsahf\n\tja\t%a\n"
stmt: GEL(rpair,freg) "\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\tfcompp\n\tfstsw\t%%ax\n\taddl\t$8,%%esp\n\tsahf\n\tja\t%a\n"
stmt: EQLO(INDIRL(addr),freg) "\tfildq\t%0\n\t\tfcompp\n\tfstsw\t%%ax\n\tandb\t$68,%%ah\n\tcmpb\t$64,%%ah\n\tje\t%a\n"
stmt: EQLO(rpair,freg) "\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\tfcompp\n\tfstsw\t%%ax\n\tandb\t$68,%%ah\n\taddl\t$8,%%esp\n\tcmpb\t$64,%%ah\n\tje\t%a\n"
stmt: EQLO(freg,INDIRL(addr)) "\tfildq\t%1\n\tfcompp\n\tfstsw\t%%ax\n\tandb\t$68,%%ah\n\tcmpb\t$64,%%ah\n\tje\t%a\n"
stmt: EQLO(freg,freg) "\tfcompp\n\tfstsw\t%%ax\n\tandb\t$68,%%ah\n\tcmpb\t$64,%%ah\n\tje\t%%a\n"
stmt: EQLO(rpair,INDIRL(addr)) "\tleal\t%1,%%ecx\n\tcmpl\t%%eax,(%%ecx)\n\tje\t%a\n\tcmpl\t4(%%ecx),%%edx\n\tje\t%a\n"
stmt: EQLO(INDIRL(addr),rpair) "\tleal\t%0,%%ecx\n\tcmpl\t%%eax,(%%ecx)\n\tje\t%a\n\tcmpl\t4(%%ecx),%%edx\n\tje\t%a\n"
stmt: NEL(INDIRL(addr),freg) "\tfildq\t%0\n\tfcompp\n\tfstsw\t%%ax\n\tandb\t$68,%%ah\n\tje\t%a\n" 8
stmt: NEL(rpair,freg) "\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\tfcompp\n\tfstsw\t%%ax\n\taddl\t$8,%%esp\n\tandb\t$68,%%ah\n\tje\t%a\n" 10
stmt: NEL(freg,freg) "\tfcompp\n\tfstsw\t%%ax\n\tandb\t$68,%%ah\n\tjne\t%a\n"
stmt: NEL(INDIRL(addr),rpair) "\tcmpl\t%%eax,%0\n\tjne\t%a\n\tleal\t%0,%%eax\n\tcmpl\t%%edx,4(%%eax)\n\tjne\t%a\n"
stmt: GTL(INDIRL(addr),freg) "\tfildq\t%0\n\tfcompp\n\tfstsw %%ax\n\tsahf\n\tja\t%a\n"
stmt: GTL(rpair,freg) "\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n_tfcompp\n\tfstsw\t%%ax\n\taddl\t$8,%%esp\n\tsahf\n\tja\t%a\n" 10
stmt: LEL(INDIRL(addr),freg) "\tfildq\t%0\n\tfcompp\n\tfstsw %%ax\n\tsahf\n\tjbe\t%a\n"
stmt: LEL(rpair,freg) "\tpushl\t%%edx\n\tpushl\t%%eax\n\tfildq\t(%%esp)\n\tfcompp\n\taddl\t$8,%%esp\n\tfstsw\t%%ax\n\tsahf\n\tjbe\t%a\n" 10
;;
;; To be compatible with microsoft's calling conventions, RETL leaves its
;; results in EAX EDX
stmt: RETL(freg) "\tsubl\t$8,%%esp\n\tfistpq\t(%%esp)\n\tpopl\t%%eax\n\tpopl\t%%edx\n" 6
stmt: RETL(rpair) "# RETL\n"
;;
;;A CALLL should retrieve the EAX EDX result
;;
rpair: CALLL(addrj)  "\tcall\t%0\n\taddl\t$%a,%%esp\n"   hasargs(a)
rpair: CALLL(addrj)  "\tcall\t%0\n" 1
stmt: ASGNL(VREGP,freg) "# write register\n"
stmt: RETI(CVLI(freg)) "\tpushl\t%%eax\n\tfistpl\t(%%esp)\n\tpop\t%%eax\n"
stmt: RETI(rpair) "# RETI(rpair)\n"
freg: CVLD(freg) "# write register\n"
freg: CVDL(freg) "# cvdl\n"
stmt: ARGI(CVCU(CVUC(reg))) "\tpushl\t%0\n"
stmt: NEI(CVCU(CVUC(CVCI(INDIRC(addr)))),con) "\tcmpb\t%1,%0\n\tjne\t%a\n"
;;
reg: JUMPI (con,con) "#escape instruction\n"
;; This rules avoid using up an intermediate register
;;
reg: ADDI(INDIRI(addr),con) "\tmovl\t%0,%c\n\taddl\t%1,%c\n"
reg: ADDU(INDIRI(addr),con) "\tmovl\t%0,%c\n\taddl\t%1,%c\n"
reg: SUBI(INDIRI(addr),con) "\tmovl\t%0,%c\n\tsubl\t%1,%c\n"
reg: SUBU(INDIRI(addr),con) "\tmovl\t%0,%c\n\tsubl\t%1,%c\n"
reg: BANDU(INDIRI(addr),con) "\tmovl\t%0,%c\n\tandl\t%1,%c\n"
reg: BORU(INDIRI(addr),con)  "\tmovl\t%0,%c\n\torl\t%1,%c\n"
reg: RSHI(INDIRI(addr),con) "\tmovl\t%0,%c\n\tsarl\t%1,%c\n"
reg: RSHU(INDIRI(addr),con) "\tmovl\t%0,%c\n\tshrl\t%1,%c\n"

;; I have separated the C files written by people from the C files
;; generated by lburg. I think this simplifies things a bit...
%%
#include "w32incl.c"
